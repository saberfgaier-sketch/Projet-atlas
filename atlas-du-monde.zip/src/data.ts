import { Continent, QuizQuestion } from './types';
import { ALL_INFLATED_EXTRA_COUNTRIES } from './countriesData';

const CONTINENTS_DATA_RAW: Continent[] = [
  {
    id: 'europe',
    name: 'L\'Europe',
    slogan: 'Terre de châteaux et d\'histoire',
    description: 'Une région magnifique chargée de contes de fées, de châteaux centenaires, d\'art célèbre et de pays incroyables qui partagent une monnaie commune, l\'Euro !',
    color: 'bg-emerald-100 border-emerald-300 text-emerald-800',
    hoverColor: 'hover:bg-emerald-200/80',
    textColor: 'text-emerald-700',
    illuSymbol: '🏰',
    countries: [
      {
        id: 'france',
        continentId: 'europe',
        name: 'La France',
        capital: 'Paris',
        flag: '🇫🇷',
        population: '68 millions de copains',
        language: 'Français',
        currency: 'Euro (€)',
        illustrationDescription: 'Une ruelle parisienne typique avec des cafés fleuris et la majestueuse Tour Eiffel en arrière-plan sous un soleil d\'été.',
        funFacts: [
          'La France est historiquement le pays le plus visité au monde par les baroudeurs et historiens en herbe !',
          'On y produit plus de 1000 variétés de fromages différents. Les Français en mangent presque à chaque repas !',
          'La Tour Eiffel grandit de quelques centimètres en plein été sous l\'effet de la chaleur (la dilatation des métaux) !'
        ],
        landmarks: [
          {
            id: 'eiffel',
            name: 'La Tour Eiffel',
            description: 'Une immense dame de fer de 330 mètres de haut. Construite par Gustave Eiffel en 1889, elle devait être détruite après 20 ans, mais a survécu grâce à la radio !'
          },
          {
            id: 'louvre',
            name: 'Le Palais du Louvre',
            description: 'Le plus grand musée d\'art du monde. Il abrite de magnifiques chefs-d\'œuvre comme la mystérieuse Joconde de Léonard de Vinci, protégée derrière une vitre pare-balle.'
          },
          {
            id: 'mont_st_michel',
            name: 'Le Mont-Saint-Michel',
            description: 'Une île châtelaine magique au milieu d\'une baie gigantesque. Deux fois par jour, la marée monte à la vitesse d\'un cheval au galop et l\'isole complètement du monde !'
          }
        ],
        cities: ['Paris', 'Marseille', 'Lyon', 'Lille', 'Bordeaux']
      },
      {
        id: 'italie',
        continentId: 'europe',
        name: 'L\'Italie',
        capital: 'Rome',
        flag: '🇮🇹',
        population: '59 millions de copains',
        language: 'Italien',
        currency: 'Euro (€)',
        illustrationDescription: 'Une place italienne baignée de soleil avec des verres de gelato, une vespa rouge garée et de magnifiques arches romaines antiques.',
        funFacts: [
          'L\'Italie a fait cadeaux au monde de la pizza, des spaghettis de la sauce tomate, et des onctueuses crèmes glacées "gelato".',
          'La célèbre Tour de Pise penche d\'un côté parce que le sol d\'argile et de sable était trop mou pour supporter son énorme poids !',
          'À l\'intérieur de Rome se cache le plus petit pays du monde entier : le Vatican, gouverné par le Pape.'
        ],
        landmarks: [
          {
            id: 'colisee',
            name: 'Le Colisée de Rome',
            description: 'Un amphithéâtre géant construit il y a près de 2000 ans ! C\'est là que les célèbres gladiateurs combattaient devant de grandes foules en liesse.'
          },
          {
            id: 'venise',
            name: 'Les Canaux de Venise',
            description: 'Une ville incroyable construite sur l\'eau avec 118 petites îles reliées par des ponts. Les gens s\'y déplacent en bateaux appelés "gondoles" !'
          },
          {
            id: 'pise',
            name: 'La Tour de Pise',
            description: 'Un clocher de marbre blanc célèbre pour son inclinaison unique de près de 4 degrés. Elle a mis près de 200 ans à être construite.'
          }
        ],
        cities: ['Rome', 'Milan', 'Venise', 'Florence', 'Naples']
      },
      {
        id: 'espagne',
        continentId: 'europe',
        name: 'L\'Espagne',
        capital: 'Madrid',
        flag: '🇪🇸',
        population: '47 millions de copains',
        language: 'Espagnol (Castillan)',
        currency: 'Euro (€)',
        illustrationDescription: 'Une scène espagnole colorée montrant des danseurs de flamenco, des mosaïques d\'Art nouveau et des palmiers sous un ciel d\'azur.',
        funFacts: [
          'Chaque année à Buñol, des milliers de personnes se jettent des tonnes de tomates bien mûres pendant la bataille festive de "La Tomatina" !',
          'C\'est le seul pays d\'Europe à avoir une frontière physique directe avec l\'Afrique continentale grâce à ses villes de Ceuta et Melilla au Maroc.',
          'La Sagrada Família, un chef-d\'œuvre d\'église à Barcelone, est en construction continue depuis 1882 ! C\'est plus long que la pyramide de Khéops.'
        ],
        landmarks: [
          {
            id: 'sagrada',
            name: 'La Sagrada Família',
            description: 'Une église conçue par l\'architecte farfelu Antoni Gaudí. Inspirée par la nature, ses piliers intérieurs ressemblent à de grands arbres formant une forêt magique.'
          },
          {
            id: 'alhambra',
            name: 'Le Palais de l\'Alhambra',
            description: 'Une sublime forteresse médiévale à Grenade qui possède d\'incroyables palais décorés d\'or, de calligraphies arabes et de fontaines d\'eau rafraîchissantes.'
          }
        ],
        cities: ['Madrid', 'Barcelone', 'Séville', 'Valence', 'Bilbao']
      }
    ]
  },
  {
    id: 'asie',
    name: 'L\'Asie',
    slogan: 'Terre de records et de secrets mystiques',
    description: 'Le plus grand continent de la Terre ! Tu y trouveras la plus haute montagne du monde, des temples magnifiques entourés de bambous sacrés, et les pays les plus peuplés.',
    color: 'bg-amber-100 border-amber-300 text-amber-800',
    hoverColor: 'hover:bg-amber-200/80',
    textColor: 'text-amber-700',
    illuSymbol: '🏮',
    countries: [
      {
        id: 'japon',
        continentId: 'asie',
        name: 'Le Japon',
        capital: 'Tokyo',
        flag: '🇯🇵',
        population: '125 millions de copains',
        language: 'Japonais',
        currency: 'Yen (¥)',
        illustrationDescription: 'Un cerisier rose en fleur ("sakura") devant le majestueux Mont Fuji couronné de neige sous un ciel bleu clair.',
        funFacts: [
          'Le Mont Fuji, le plus beau symbole du pays, est en réalité un grand volcan sacré toujours actif !',
          'Le Shinkansen est l\'un des trains les plus rapides du monde avec son nez fuselé en bec de canard. Il est réputé pour sa ponctualité à la seconde près.',
          'Il y a plus de 5 millions de distributeurs automatiques insolites au Japon proposant des boissons chaudes, des ramen ou même des jouets !'
        ],
        landmarks: [
          {
            id: 'fuji',
            name: 'Le Mont Fuji',
            description: 'Un volcan endormi parfait de 3776 mètres de hauteur, vénéré par les artistes depuis des siècles. C\'est l\'un des trois sommets sacrés du Japon.'
          },
          {
            id: 'temple_or',
            name: 'Le Temple d\'Or (Kinkaku-ji)',
            description: 'Un magnifique pavillon bouddhiste à Kyoto entièrement recouvert de feuilles d\'or pur qui scintille de mille feux dans l\'eau calme de son étang.'
          }
        ],
        cities: ['Tokyo', 'Kyoto', 'Osaka', 'Sapporo', 'Hiroshima']
      },
      {
        id: 'inde',
        continentId: 'asie',
        name: 'L\'Inde',
        capital: 'New Delhi',
        flag: '🇮🇳',
        population: '1,4 milliard de copains',
        language: 'Hindi et Anglais',
        currency: 'Roupie indienne (₹)',
        illustrationDescription: 'Le somptueux Taj Mahal blanc se reflétant dans le canal, entouré d\'éléphants sacrés décorés de motifs festifs de la fête de Holi.',
        funFacts: [
          'L\'Inde est le royaume des merveilleux tigres sauvages : elle abrite plus de 70% de tous les tigres de la planète !',
          'Les délicieux jeux d\'Échecs et la philosophie du Yoga sont nés en Inde il y a plusieurs milliers d\'années.',
          'Chaque printemps, les Indiens célèbrent la fête de Holi en se jetant de la poudre colorée dans une liesse magique qui salue l\'arrivée du printemps.'
        ],
        landmarks: [
          {
            id: 'taj_mahal',
            name: 'Le Taj Mahal',
            description: 'Un immense monument de marbre blanc immaculé construit à Agra par un empereur moghol en souvenir de sa femme bien-aimée. C\'est un symbole éternel d\'amour.'
          },
          {
            id: 'gange',
            name: 'Le Fleuve Gange',
            description: 'Un fleuve mystique et sacré de 2500 km ! Pour les hindous, il guérit les malades et nettoie les péchés de ceux qui se baignent dans ses eaux.'
          }
        ],
        cities: ['New Delhi', 'Bombay (Mumbai)', 'Bangalore', 'Calcutta', 'Jaipur']
      },
      {
        id: 'chine',
        continentId: 'asie',
        name: 'La Chine',
        capital: 'Pékin (Beijing)',
        flag: '🇨🇳',
        population: '1,4 milliard de copains',
        language: 'Mandarin (Chinois)',
        currency: 'Yuan (¥)',
        illustrationDescription: 'La spectaculaire muraille sinueuse traversant des montagnes embrumées, avec un joyeux panda géant mangeant des feuilles de bambou rigides.',
        funFacts: [
          'La grandiose Grande Muraille est si gigantesque qu\'elle mesure plus de 21 000 kilomètres de long, soit la moitié de la circonférence terrestre !',
          'La formule magique du papier, la boussole, l\'imprimerie et la poudre des feux d\'artifice ont tous été découverts en Chine antique !',
          'Tous les pandas géants de la planète appartiennent légalement à la Chine ! Ils sont loués aux zoos du monde entier.'
        ],
        landmarks: [
          {
            id: 'grande_muraille',
            name: 'La Grande Muraille de Chine',
            description: 'Une suite colossale de murs fortifiés érigés pour repousser les armées ennemies. Son tracé ondule sur les crêtes rocheuses comme le dos d\'un énorme dragon de pierre.'
          },
          {
            id: 'cite_interdite',
            name: 'La Cité Interdite',
            description: 'Un ensemble secret composé de 980 palais traditionnels en bois laqué rouge et toit d\'or, où logeaient les empereurs de Chine sans jamais en sortir.'
          }
        ],
        cities: ['Pékin', 'Shanghai', 'Canton (Guangzhou)', 'Shenzhen', 'Hong Kong']
      }
    ]
  },
  {
    id: 'afrique',
    name: 'L\'Afrique',
    slogan: 'Le berceau de l\'humanité et de la nature sauvage',
    description: 'Une terre ensoleillée incroyable, de déserts immenses sous les étoiles, de savanes abritant de grands lions et de fleuves majestueux où nagent les crocodiles.',
    color: 'bg-orange-100 border-orange-300 text-orange-800',
    hoverColor: 'hover:bg-orange-200/80',
    textColor: 'text-orange-700',
    illuSymbol: '🦁',
    countries: [
      {
        id: 'maroc',
        continentId: 'afrique',
        name: 'Le Maroc',
        capital: 'Rabat',
        flag: '🇲🇦',
        population: '37 millions de copains',
        language: 'Arabe et Amazighe',
        currency: 'Dirham marocain (DH)',
        illustrationDescription: 'Une kasbah couleur terre ocre entourée de palmiers et de dunes de sable fin, parfumée au thé à la menthe fumant.',
        funFacts: [
          'Au Maroc, les fameuses chèvres grimpent à la cime des arbres d\'argan pour en déguster les délicieux fruits ovales !',
          'La plus ancienne université du monde encore en activité a été fondée par une femme du nom de Fatima al-Fihriya en l\'an 859 à Fès !',
          'La fabuleuse ville bleue de Chefchaouen est entièrement peinte en teintes de bleu azur magique pour éloigner les moustiques !'
        ],
        landmarks: [
          {
            id: 'jemaa_fna',
            name: 'La Place Jemaa el-Fna',
            description: 'Un grand théâtre à ciel ouvert situé à Marrakech avec des charmeurs de serpents de terre, des diseurs de contes passionnés et des stands d\'épices colorées.'
          },
          {
            id: 'mont_atlas',
            name: 'Les Montagnes de l\'Atlas',
            description: 'Une chaîne montagneuse majestueuse dont le plus haut sommet est le mont Toubkal. Elles séparent les côtes fraîches du grand désert brûlant du Sahara.'
          }
        ],
        cities: ['Rabat', 'Casablanca', 'Marrakech', 'Fès', 'Tanger']
      },
      {
        id: 'egypte',
        continentId: 'afrique',
        name: 'L\'Égypte',
        capital: 'Le Caire',
        flag: '🇪🇬',
        population: '110 millions de copains',
        language: 'Arabe',
        currency: 'Livre égyptienne (EGP)',
        illustrationDescription: 'Les célèbres pyramides pointues se dressant majestueusement au milieu du sable sous le regard fier d\'un majestueux sphinx de pierre.',
        funFacts: [
          'Le grand fleuve du Nil, l\'une des plus grandes sources de vie du monde, traverse tout l\'Égypte aride pour se jeter dans la mer Méditerranée.',
          'Les formidables Pharaons de l\'Antiquité ont fait ériger la pyramide de Khéops il y a plus de 4500 ans en l\'honneur de leur voyage céleste !',
          'Chez les Égyptiens de l\'Antiquité, le chat était vénéré comme un dieu protecteur et embaumé avec tendresse à sa mort.'
        ],
        landmarks: [
          {
            id: 'pyramides',
            name: 'Les Pyramides de Gizeh',
            description: 'Trois tombeaux colossaux érigés pour d\'anciens pharaons égyptiens. La plus grande est bâtie avec plus de 2,3 millions de blocs de pierre pesant chacun une tonne !'
          },
          {
            id: 'sphinx',
            name: 'Le Grand Sphinx',
            description: 'Une statue sculptée fantastique longue de 73 mètres, avec le corps fort d\'un lion et la tête intelligente d\'un roi pharaon.'
          }
        ],
        cities: ['Le Caire', 'Alexandrie', 'Louxor', 'Assouan', 'Charm el-Cheikh']
      },
      {
        id: 'afrique_sud',
        continentId: 'afrique',
        name: 'L\'Afrique du Sud',
        capital: 'Pretoria (Administrative)',
        flag: '🇿🇦',
        population: '60 millions de copains',
        language: '11 langues officielles !',
        currency: 'Rand (R)',
        illustrationDescription: 'Une colline côtière spectaculaire avec des manchots s\'amusant sur le rivage sableux, et un grand lion rugissant fièrement.',
        funFacts: [
          'L\'Afrique du Sud possède une incroyable colonie sauvage de manchots en frac sur la célèbre plage de sable fin de Boulders Beach !',
          'C\'est le seul pays moderne de la Terre à être entouré de deux océans différents : l\'Atlantique frais et l\'Indien chaud.',
          'Elle abrite le parc Kruger, de la taille d\'un petit pays européen, où l\'on peut admirer les lions, girafes et léopards en liberté.'
        ],
        landmarks: [
          {
            id: 'table_mountain',
            name: 'La Montagne de la Table',
            description: 'Une montagne magique dont le sommet est totalement plat comme une table de géant. Ses falaises abruptes sont souvent recouvertes d\'une "nappe" de nuages.'
          },
          {
            id: 'kruger',
            name: 'Le Parc National Kruger',
            description: 'La plus grande réserve de faune sauvage d\'Afrique du Sud. C\'est le havre de paix idéal pour photographier les rhinocéros, zèbres et les oiseaux colorés.'
          }
        ],
        cities: ['Pretoria', 'Le Cap (Cape Town)', 'Johannesbourg', 'Durban', 'Port Elizabeth']
      }
    ]
  },
  {
    id: 'amerique_nord',
    name: 'L\'Amérique du Nord',
    slogan: 'Des gratte-ciels géants aux parcs légendaires',
    description: 'Une terre d\'aventure pleine de contrastes ! Des métropoles de verre s\'étendent à côté de lacs bleus étincelants, de parcs de séquoias géants et d\'immenses forêts de sapins.',
    color: 'bg-sky-100 border-sky-300 text-sky-800',
    hoverColor: 'hover:bg-sky-200/80',
    textColor: 'text-sky-700',
    illuSymbol: '🍁',
    countries: [
      {
        id: 'canada',
        continentId: 'amerique_nord',
        name: 'Le Canada',
        capital: 'Ottawa',
        flag: '🇨🇦',
        population: '38 millions de copains',
        language: 'Français et Anglais',
        currency: 'Dollar canadien ($)',
        illustrationDescription: 'Un lac turquoise de montagne entouré de sapins verts, réfléchissant un canoë rouge et une grande feuille d\'érable rouge.',
        funFacts: [
          'Le Canada possède plus de lacs d\'eau douce que tous les autres pays du monde du globe réunis !',
          'Le délicieux sirop d\'érable, fabriqué à base de sève d\'arbre bouillie, est l\'emblème du pays avec le castor bâtisseur.',
          'Il y fait si froid en hiver que les enfants chaussent leurs patins pour jouer au hockey sur glace sur les canaux gelés de la ville !'
        ],
        landmarks: [
          {
            id: 'niagara',
            name: 'Les Chutes du Niagara',
            description: 'Trois cascades géantes extraordinairement puissantes situées à la frontière américaine. L\'équivalent de un million de baignoires d\'eau s\'y déverse chaque seconde !'
          },
          {
            id: 'banff',
            name: 'Le Parc National de Banff',
            description: 'Situé au cœur des montagnes Rocheuses rudes, ce parc abrite des lacs à l\'eau bleu-turquoise laiteuse et des ours grizzlys sauvages.'
          }
        ],
        cities: ['Ottawa', 'Toronto', 'Montréal', 'Vancouver', 'Québec']
      },
      {
        id: 'usa',
        continentId: 'amerique_nord',
        name: 'Les États-Unis',
        capital: 'Washington D.C.',
        flag: '🇺🇸',
        population: '332 millions de copains',
        language: 'Anglais',
        currency: 'Dollar américain ($)',
        illustrationDescription: 'La majestueuse Statue de la Liberté brandissant son flambeau face à la skyline de New York et un aigle à tête blanche volant haut.',
        funFacts: [
          'La fameuse Statue de la Liberté à New York a été entièrement imaginée, fabriquée et offerte par la France à l\'Amérique en signe d\'alliance !',
          'C\'est l\'inventeur officiel de la bande dessinée modernisée de super-héros et du cinéma à grand spectacle d\'Hollywood !',
          'On y observe les séquoias géants de Californie, des arbres majestueux si larges qu\'une voiture entière pourrait passer en leur milieu !'
        ],
        landmarks: [
          {
            id: 'liberte',
            name: 'La Statue de la Liberté',
            description: 'Une colossale sculpture de cuivre vert de près de 93 mètres de haut. Elle accueille chaleureusement les marins arrivant dans la baie de New York.'
          },
          {
            id: 'grand_canyon',
            name: 'Le Grand Canyon',
            description: 'Une gorge gigantesque creusée par la rivière Colorado. Ses parois rocheuses de couleur orange-rouge changent spectaculairement de couleur avec le soleil.'
          }
        ],
        cities: ['Washington', 'New York', 'Los Angeles', 'Chicago', 'Miami']
      },
      {
        id: 'mexique',
        continentId: 'amerique_nord',
        name: 'Le Mexique',
        capital: 'Mexico',
        flag: '🇲🇽',
        population: '128 millions de copains',
        language: 'Espagnol',
        currency: 'Peso mexicain ($)',
        illustrationDescription: 'Une pyramide maya en pierre entourée d\'un cactus vert saguaro sauvage, avec un chapeau sombrero coloré et un régal de tacos.',
        funFacts: [
          'Le délicieux chocolat a été récolté et cuisiné pour la première fois en boisson divine sacrée par les Mayas au Mexique antique !',
          'La pyramide maya de Chichén Itzá est l\'une des sept nouvelles merveilles du monde moderne, construite en hommage aux étoiles.',
          'Le Chihuahua, le plus petit toutou du monde doté de grandes oreilles, tire son nom de l\'État sauvage du nord du Mexique !'
        ],
        landmarks: [
          {
            id: 'chichen_itza',
            name: 'Le Temple de Kukulcán (Chichén Itzá)',
            description: 'Une colossale pyramide à degrés construite par les Mayas. À chaque équinoxe, les ombres du soleil font descendre visuellement un serpent le long de ses marches !'
          },
          {
            id: 'tulum',
            name: 'Les Ruines de Tulum',
            description: 'Les vestiges d\'un ancien port de commerce fortifié maya perché tout au bord d\'une falaise face aux eaux limpides des Caraïbes.'
          }
        ],
        cities: ['Mexico', 'Cancún', 'Guadalajara', 'Monterrey', 'Oaxaca']
      }
    ]
  },
  {
    id: 'amerique_sud',
    name: 'L\'Amérique du Sud',
    slogan: 'L\'empire de la forêt géante et du carnaval',
    description: 'Une région sauvage dominée par l\'immense forêt tropicale d\'Amazonie, de magnifiques lamas marchant sur les hauts sommets de la Cordillère des Andes et des plages en fête.',
    color: 'bg-teal-100 border-teal-300 text-teal-800',
    hoverColor: 'hover:bg-teal-200/80',
    textColor: 'text-teal-700',
    illuSymbol: '🦜',
    countries: [
      {
        id: 'bresil',
        continentId: 'amerique_sud',
        name: 'Le Brésil',
        capital: 'Brasilia',
        flag: '🇧🇷',
        population: '214 millions de copains',
        language: 'Portugais',
        currency: 'Réal brésilien (R$)',
        illustrationDescription: 'L\'immense statue du Christ étendant les bras sur les baies bleues de Rio de Janeiro, parfumée par des fruits exotiques tropicaux.',
        funFacts: [
          'L\'immense Fleuve Amazone traverse le Brésil sauvage et déverse plus d\'eau douce dans la mer que tous les autres fleuves réunis !',
          'Le football est ici une passion absolue, et le pays détient le record mondial de 5 victoires en Coupe du Monde !',
          'Le carnaval de Rio est la plus grandiose fête rythmée du monde avec ses cortèges de chars géants et ses danseurs masqués.'
        ],
        landmarks: [
          {
            id: 'christ_redempteur',
            name: 'Le Christ Rédempteur',
            description: 'Une monumentale statue art déco en béton de 38 mètres qui veille sagement du sommet de la colline du Corcovado sur les plages mythiques de Rio de Janeiro.'
          },
          {
            id: 'iguazu',
            name: 'Les Chutes d\'Iguazu',
            description: 'Une suite majestueuse de 275 cascades de jungle s\'écoulant dans un vacarme assourdissant, entourée d\'arc-en-ciel scintillants et de toucans sauvages.'
          }
        ],
        cities: ['Brasilia', 'Rio de Janeiro', 'São Paulo', 'Salvador', 'Manaus']
      },
      {
        id: 'perou',
        continentId: 'amerique_sud',
        name: 'Le Pérou',
        capital: 'Lima',
        flag: '🇵🇪',
        population: '33 millions de copains',
        language: 'Espagnol et Quechua',
        currency: 'Sol (S/)',
        illustrationDescription: 'Les mystérieuses ruines incas de Machu Picchu nichées au cœur des cimes montagneuses vertes avec un petit lama curieux.',
        funFacts: [
          'Le fabuleux Empire Inca a construit sa cité sacrée du Machu Picchu à plus de 2400 mètres de hauteur, sans aucun outil en fer !',
          'Le Pérou est le roi incontesté de la patate : on y cultive plus de 3000 espèces différentes de pommes de terre !',
          'Le grand lac Titicaca, situé à cheval sur le Pérou, est le plus haut lac navigable de notre planète Terre à 3800 mètres.'
        ],
        landmarks: [
          {
            id: 'machu_picchu',
            name: 'Le Machu Picchu',
            description: 'Une incroyable cité d\'altitude inca en pierres polies assemblées à la perfection sans mortier. Cachée des conquérants espagnols, elle fut redécouverte en 1911.'
          },
          {
            id: 'titicaca',
            name: 'Le Lac Titicaca',
            description: 'Un immense lac d\'altitude sur lequel vivent des communautés amérindiennes historiques naviguant sur des îles de jonc tressé flottantes appelées uros.'
          }
        ],
        cities: ['Lima', 'Cusco', 'Arequipa', 'Iquitos', 'Trujillo']
      }
    ]
  },
  {
    id: 'oceanie',
    name: 'L\'Océanie',
    slogan: 'Le paradis des coraux bleus et du surf',
    description: 'Une constellation magique de milliers d\'îles éparpillées au cœur du grand Océan Pacifique sauvage. C\'est le royaume des coraux bleus, des koalas dodus et de la culture Maorie.',
    color: 'bg-cyan-100 border-cyan-300 text-cyan-800',
    hoverColor: 'hover:bg-cyan-200/80',
    textColor: 'text-cyan-700',
    illuSymbol: '🦘',
    countries: [
      {
        id: 'australie',
        continentId: 'oceanie',
        name: 'L\'Australie',
        capital: 'Canberra',
        flag: '🇦🇺',
        population: '26 millions de copains',
        language: 'Anglais',
        currency: 'Dollar australien ($)',
        illustrationDescription: 'L\'Opéra de Sydney blanc en voiles géantes avec des kangourous bondissants et des poissons exotiques de récif corallien.',
        funFacts: [
          'L\'Australie abrite des créatures sauvages féeriques uniques comme le kangourou sauteur, le koala grimpeur et l\'ornithorynque venimeux à bec de canard !',
          'La Grande Barrière de corail est la plus longue entité vivante du globe et s\'admire même depuis la navette spatiale !',
          'Il y a près de dix fois plus de moutons dodus en Australie que d\'habitants de chair et d\'os !'
        ],
        landmarks: [
          {
            id: 'opera_sydney',
            name: 'L\'Opéra de Sydney',
            description: 'Un splendide édifice moderne dont l\'architecture rappelle des coquillages ou les voiles géantes d\'un galion pointées vers la mer de Tasmanie.'
          },
          {
            id: 'uluru',
            name: 'Le Rocher d\'Uluru',
            description: 'Un monolithe rocheux rougeoyant géant et sacré pour le peuple aborigène, trônant fièrement tout seul au beau milieu du désert aride d\'Australie.'
          }
        ],
        cities: ['Canberra', 'Sydney', 'Melbourne', 'Brisbane', 'Perth']
      },
      {
        id: 'nz',
        continentId: 'oceanie',
        name: 'La Nouvelle-Zélande',
        capital: 'Wellington',
        flag: '🇳🇿',
        population: '5 millions de copains',
        language: 'Anglais et Maori',
        currency: 'Dollar néo-zélandais ($)',
        illustrationDescription: 'Des collines herbeuses vertes piquetées d\'entrées circulaires de terriers de Hobbits, sous le regard d\'un petit oiseau kiwi tacheté.',
        funFacts: [
          'Le symbole du pays est le "Kiwi", un petit oiseau poilu drôle et sans ailes qui ne sort sa tête curieuse que durant les nuits calmes !',
          'La Nouvelle-Zélande a été le tout premier pays souverain du monde à accorder le droit de vote aux mamans et filles courageuses dès 1893.',
          'Ses fjords côtiers profonds et ses sources bouillonnantes ont servi d\'écrin de tournage naturel des sublimes films de fan-fiction fantastique.'
        ],
        landmarks: [
          {
            id: 'hobbiton',
            name: 'Le village de Hobbiton',
            description: 'Le vrai village pittoresque aux 44 maisons sous terre miniatures avec leurs petites portes colorées rondes, construit originellement pour incarner la Comté au cinéma.'
          },
          {
            id: 'rotorua',
            name: 'Les sources de Rotorua',
            description: 'Une vallée volcanique active fantastique réputée pour ses vapeurs de soufre s\'élevant du sol rocheux et ses geysers bleutés bouillonnants.'
          }
        ],
        cities: ['Wellington', 'Auckland', 'Christchurch', 'Queenstown', 'Hamilton']
      }
    ]
  },
  {
    id: 'antarctique',
    name: 'L\'Antarctique',
    slogan: 'L\'immense continent blanc et mystérieux',
    description: 'Une banquise de glace géante de plusieurs kilomètres d\'épaisseur où le soleil ne se couche jamais en été. Aucun pays n\'y est installé, c\'est un laboratoire géant.',
    color: 'bg-fuchsia-100 border-fuchsia-300 text-fuchsia-800',
    hoverColor: 'hover:bg-fuchsia-200/80',
    textColor: 'text-fuchsia-700',
    illuSymbol: '❄️',
    countries: [
      {
        id: 'base_amundsen',
        continentId: 'antarctique',
        name: 'La Base Amundsen-Scott',
        capital: 'Pas de capitale (Laboratoire scientifique international)',
        flag: '🇦🇶',
        population: 'Environ 1000 à 5000 chercheurs (selon les saisons !)',
        language: 'Toutes les langues des nations (Anglais principalement)',
        currency: 'Pas de pièces ou billets ! (C\'est une zone protégée par traité)',
        illustrationDescription: 'Une base sur pilotis métallique isolée sur une banquise infinie, sous une somptueuse aurore australe verte ondulant dans l\'obscurité polaire.',
        funFacts: [
          'L\'Antarctique est le continent le plus froid (-89°C mesurés !), mais c\'est également le désert le plus aride de la Terre car il n\'y pleut jamais !',
          'Son sol est recouvert de glace à 98% qui stocke à elle seule 70% de toute l\'eau douce existante sur notre planète Terre !',
          'C\'est la patrie absolue des somptueux manchots empereurs qui y couvent leurs précieux œufs en chantant au milieu des tempêtes froides.'
        ],
        landmarks: [
          {
            id: 'pole_sud',
            name: 'Le pôle Sud géographique',
            description: 'L\'exact point de convergence le plus austral de la Terre, marqué par une sphère colorée en miroir entourée des drapeaux des 12 nations fondatrices.'
          },
          {
            id: 'aurore',
            name: 'Le rideau d\'Aurore Australe',
            description: 'Des voiles de lumière colorée émeraude ou pourpre dansants s\'allumant dans l\'atmosphère nocturne polaire lorsque le vent solaire frappe notre champ magnétique.'
          }
        ],
        cities: ['Base Amundsen-Scott', 'Base de McMurdo', 'Base de Concordia', 'Base de Dumont d\'Urville']
      }
    ]
  }
];

export const CONTINENTS_DATA: Continent[] = CONTINENTS_DATA_RAW.map((continent) => {
  const extras = ALL_INFLATED_EXTRA_COUNTRIES.filter((c) => c.continentId === continent.id);
  const existingIds = new Set(continent.countries.map((c) => c.id));
  const uniqueExtras = extras.filter((c) => !existingIds.has(c.id));
  return {
    ...continent,
    countries: [...continent.countries, ...uniqueExtras]
  };
});

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    type: 'capital',
    questionText: 'Quelle est la magnifique capitale de la France, aussi connue sous le nom de "Ville Lumière" ?',
    options: ['Londres', 'Marseille', 'Paris', 'Rome'],
    correctAnswer: 'Paris',
    funExplanation: 'Super ! Paris abrite la grandiose Tour Eiffel et la célèbre Joconde dans son magnifique palais du Louvre !'
  },
  {
    id: 'q2',
    type: 'flag',
    questionText: 'À quel pays appartient ce magnifique drapeau coloré : 🇯🇵 ?',
    options: ['La Chine', 'Le Japon', 'Le Canada', 'Le Brésil'],
    correctAnswer: 'Le Japon',
    funExplanation: 'Exactement ! Le rond rouge central sur fond blanc symbolise le Soleil Levant, l\'astre de vie très respecté au Japon !'
  },
  {
    id: 'q3',
    type: 'continent',
    questionText: 'Dans quel continent magique peut-on observer les adorables lamas et explorer la cité perdue du Machu Picchu ?',
    options: ['L\'Océanie', 'L\'Afrique', 'L\'Amérique du Sud', 'L\'Europe'],
    correctAnswer: 'L\'Amérique du Sud',
    funExplanation: 'Incroyable ! Le Pérou est un pays de l\'Amérique du Sud, réputé pour ses lamas gardiens des hauts sommets de la Cordillère des Andes.'
  },
  {
    id: 'q4',
    type: 'capital',
    questionText: 'Quelle est la drôle de capitale officielle de l\'Espagne, située pile au centre du pays ?',
    options: ['Barcelone', 'Séville', 'Madrid', 'Lisbonne'],
    correctAnswer: 'Madrid',
    funExplanation: 'Bravo ! Madrid abrite le splendide Palais Royal et de sublimes parcs arborés comme le parc du Retiro !'
  },
  {
    id: 'q5',
    type: 'landmark',
    questionText: 'Où peut-on se promener dans la célèbre forêt enchantée des Hobbits (Hobbiton) ?',
    options: ['Au Canada', 'En Nouvelle-Zélande', 'En Italie', 'En Inde'],
    correctAnswer: 'En Nouvelle-Zélande',
    funExplanation: 'Magnifique ! Les superbes cinéastes ont choisi la Nouvelle-Zélande pour y bâtir les ravissantes collines herbeuses des Hobbits.'
  },
  {
    id: 'q6',
    type: 'continent',
    questionText: 'Quel est le continent le plus froid de la Terre, où les manchots sont les véritables rois de la banquise ?',
    options: ['L\'Afrique', 'L\'Océanie', 'L\'Antarctique', 'L\'Asie'],
    correctAnswer: 'L\'Antarctique',
    funExplanation: 'Bien joué ! L\'Antarctique est recouvert d\'une épaisse calotte glaciaire blanche où travaillent de fiers et courageux scientifiques.'
  },
  {
    id: 'q7',
    type: 'capital',
    questionText: 'Sais-tu quelle est la capitale du majestueux Canada, le pays de la feuille d\'érable ?',
    options: ['Montréal', 'Toronto', 'Ottawa', 'Vancouver'],
    correctAnswer: 'Ottawa',
    funExplanation: 'C\'est juste ! Bien que Montréal et Toronto soient d\'immenses villes canadiennes, la capitale politique du pays est la tranquille Ottawa !'
  },
  {
    id: 'q8',
    type: 'landmark',
    questionText: 'Quel monument historique a été construit il y a des siècles à Agra, en Inde, tout en marbre blanc éclatant ?',
    options: ['La Statue de la Liberté', 'Le Colisée de Rome', 'Le Taj Mahal', 'La Tour Eiffel'],
    correctAnswer: 'Le Taj Mahal',
    funExplanation: 'Merveilleux ! Le Taj Mahal a été érigé par l\'Empereur Shah Jahan en témoignage d\'un amour impérial impérissable.'
  },
  {
    id: 'q9',
    type: 'flag',
    questionText: 'As-tu déjà deviné à quel pays appartient ce grand drapeau vert et étoilé : 🇲🇦 ?',
    options: ['L\'Égypte', 'Le Maroc', 'Le Pérou', 'L\'Italie'],
    correctAnswer: 'Le Maroc',
    funExplanation: 'Oui ! Ce drapeau rouge avec un pentagramme vert de cinq branches symbolise le Royaume millénaire du Maroc !'
  },
  {
    id: 'q10',
    type: 'flag',
    questionText: 'Quel animal sauteur d\'Océanie est l\'image emblématique de l\'Australie 🇦🇺 ?',
    options: ['Le Panda', 'Le Koala', 'Le Kangourou', 'Le Lion'],
    correctAnswer: 'Le Kangourou',
    funExplanation: 'Génial ! Les kangourous utilisent leur grande queue puissante comme ressort pour bondir sur de formidables distances sauvages !'
  }
];
