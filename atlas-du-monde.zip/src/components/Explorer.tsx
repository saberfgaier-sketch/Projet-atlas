import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Compass, Users, MapPin, Award } from 'lucide-react';
import { Continent, Country } from '../types';
import { CONTINENTS_DATA } from '../data';

interface ExplorerProps {
  focusedContinent: Continent | null;
  setFocusedContinent: (continent: Continent | null) => void;
  focusedCountry: Country | null;
  setFocusedCountry: (country: Country | null) => void;
  onSelectCountry: (country: Country) => void;
}

export default function Explorer({
  focusedContinent,
  setFocusedContinent,
  focusedCountry,
  setFocusedCountry,
  onSelectCountry
}: ExplorerProps) {
  const [localSearchQuery, setLocalSearchQuery] = useState('');

  const handleContinentClick = (continent: Continent) => {
    setFocusedContinent(continent);
    setFocusedCountry(null);
    setLocalSearchQuery('');
  };

  const clearSelection = () => {
    setFocusedContinent(null);
    setFocusedCountry(null);
    setLocalSearchQuery('');
  };

  const filteredCountries = focusedContinent
    ? focusedContinent.countries.filter(country =>
        country.name.toLowerCase().includes(localSearchQuery.toLowerCase()) ||
        country.capital.toLowerCase().includes(localSearchQuery.toLowerCase())
      )
    : [];

  const containerVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4, staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100 } }
  };

  return (
    <div className="space-y-8" id="explorer-module">
      {/* 1. World Map Overview (No continent focused) */}
      {!focusedContinent && (
        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="space-y-8"
        >
          {/* Welcome Dashboard matching Vibrant Palette */}
          <div className="bg-indigo-500 rounded-[2.5rem] p-8 sm:p-12 text-white shadow-xl text-left relative overflow-hidden" id="hero-banner">
            <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_50%_120%,#ffffff_0%,transparent_50%)] pointer-events-none"></div>
            
            <div className="relative z-10 flex flex-col max-w-2xl">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-4xl sm:text-5xl animate-wiggle inline-block">🪐</span>
                <h2 className="text-3xl sm:text-5xl font-black font-sans tracking-tight">
                  Prêt pour l'aventure ?
                </h2>
              </div>
              <p className="text-indigo-100 text-sm sm:text-base font-bold leading-relaxed">
                Clique sur un continent de la carte ou parcours les cartes colorées ci-dessous pour découvrir des secrets insolites, des animaux rigolos et des monuments magiques de notre planète !
              </p>
            </div>

            {/* Floating theme compass */}
            <div className="hidden md:flex absolute right-12 top-1/2 -translate-y-1/2 w-40 h-40 bg-white/10 rounded-full border-4 border-white/20 items-center justify-center text-7xl select-none rotate-12 animate-wiggle">
              🧭
            </div>
          </div>

          {/* Interactive SVG simplified World Map */}
          <div className="bg-white rounded-[2rem] p-4 sm:p-6 border-4 border-sky-150 shadow-sm text-center">
            <h3 className="text-xs font-black text-sky-500 uppercase tracking-widest mb-3 flex items-center justify-center gap-1.5 font-mono">
              <Compass className="w-4 h-4 text-sky-500 animate-spin-slow" />
              Carte interactive du monde
            </h3>
            
            <div className="max-w-3xl mx-auto aspect-[2/1] relative bg-sky-200/40 rounded-2xl border-2 border-sky-200/60 overflow-hidden flex items-center justify-center">
              {/* Decorative dotted grid lines */}
              <div className="absolute inset-0 grid grid-cols-6 grid-rows-3 opacity-20 pointer-events-none">
                <div className="border-r border-b border-sky-600 border-dashed" />
                <div className="border-r border-b border-sky-600 border-dashed" />
                <div className="border-r border-b border-sky-600 border-dashed" />
                <div className="border-r border-b border-sky-600 border-dashed" />
                <div className="border-r border-b border-sky-600 border-dashed" />
                <div className="border-r border-b border-sky-600 border-dashed" />
              </div>

              {/* Vector representation zones as clickable cartoon elements */}
              <svg className="w-full h-full p-2" viewBox="0 0 600 300" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* 1. North America Sky Blue */}
                <g 
                  className="cursor-pointer group" 
                  onClick={() => handleContinentClick(CONTINENTS_DATA.find(c => c.id === 'amerique_nord')!)}
                  id="svg-amerique-nord"
                >
                  <path d="M 60 40 Q 110 30 150 50 Q 180 80 140 120 Q 80 140 70 80 Z" fill="#bae6fd" stroke="#38bdf8" strokeWidth="4" className="group-hover:fill-sky-200 transition-colors duration-300" />
                  <text x="100" y="80" fill="#0369a1" className="font-extrabold text-xs select-none pointer-events-none">Am. Nord 🍁</text>
                </g>

                {/* 2. South America Teal */}
                <g 
                  className="cursor-pointer group" 
                  onClick={() => handleContinentClick(CONTINENTS_DATA.find(c => c.id === 'amerique_sud')!)}
                  id="svg-amerique-sud"
                >
                  <path d="M 120 130 Q 180 140 160 190 Q 130 250 110 260 Q 90 200 100 150 Z" fill="#99f6e4" stroke="#2dd4bf" strokeWidth="4" className="group-hover:fill-teal-200 transition-colors duration-300" />
                  <text x="125" y="180" fill="#0f766e" className="font-extrabold text-xs select-none pointer-events-none">Am. Sud 🦜</text>
                </g>

                {/* 3. Europe Emerald */}
                <g 
                  className="cursor-pointer group" 
                  onClick={() => handleContinentClick(CONTINENTS_DATA.find(c => c.id === 'europe')!)}
                  id="svg-europe"
                >
                  <path d="M 240 50 Q 290 40 310 65 Q 260 90 230 80 Z" fill="#a7f3d0" stroke="#34d399" strokeWidth="4" className="group-hover:fill-emerald-200 transition-colors duration-300" />
                  <text x="255" y="65" fill="#047857" className="font-extrabold text-xs select-none pointer-events-none">Europe 🏰</text>
                </g>

                {/* 4. Africa Orange */}
                <g 
                  className="cursor-pointer group" 
                  onClick={() => handleContinentClick(CONTINENTS_DATA.find(c => c.id === 'afrique')!)}
                  id="svg-afrique"
                >
                  <path d="M 230 100 Q 290 90 310 130 Q 290 200 250 190 Q 210 150 220 110 Z" fill="#fed7aa" stroke="#fb923c" strokeWidth="4" className="group-hover:fill-orange-200 transition-colors duration-300" />
                  <text x="250" y="140" fill="#c2410c" className="font-extrabold text-xs select-none pointer-events-none">Afrique 🦁</text>
                </g>

                {/* 5. Asia Amber */}
                <g 
                  className="cursor-pointer group" 
                  onClick={() => handleContinentClick(CONTINENTS_DATA.find(c => c.id === 'asie')!)}
                  id="svg-asie"
                >
                  <path d="M 310 40 Q 420 20 450 70 Q 480 120 380 130 Q 320 100 310 60 Z" fill="#fef08a" stroke="#facc15" strokeWidth="4" className="group-hover:fill-amber-200 transition-colors duration-300" />
                  <text x="370" y="75" fill="#a16207" className="font-extrabold text-xs select-none pointer-events-none">Asie 🏮</text>
                </g>

                {/* 6. Oceania Purple/Indigo/Cyan */}
                <g 
                  className="cursor-pointer group" 
                  onClick={() => handleContinentClick(CONTINENTS_DATA.find(c => c.id === 'oceanie')!)}
                  id="svg-oceanie"
                >
                  <path d="M 450 150 Q 510 140 520 180 Q 460 210 440 170 Z" fill="#cffafe" stroke="#22d3ee" strokeWidth="4" className="group-hover:fill-cyan-200 transition-colors duration-300" />
                  <text x="465" y="175" fill="#0e7490" className="font-extrabold text-xs select-none pointer-events-none">Océanie 🦘</text>
                </g>

                {/* 7. Antarctica Fuchsia */}
                <g 
                  className="cursor-pointer group" 
                  onClick={() => handleContinentClick(CONTINENTS_DATA.find(c => c.id === 'antarctique')!)}
                  id="svg-antarctique"
                >
                  <path d="M 120 275 Q 300 265 480 275 L 480 290 L 120 290 Z" fill="#fbcfe8" stroke="#f472b6" strokeWidth="4" className="group-hover:fill-fuchsia-200 transition-colors duration-300" />
                  <text x="270" y="285" fill="#be185d" className="font-extrabold text-xs select-none pointer-events-none">Antarctique ❄️</text>
                </g>

                {/* Equatorial Ring line */}
                <line x1="0" y1="145" x2="600" y2="145" stroke="#0284c7" strokeWidth="2" strokeDasharray="6 6" opacity="0.4" />
                <text x="10" y="140" fill="#0284c7" className="font-mono text-[9px] font-bold tracking-wide opacity-50">ÉQUATEUR ☀️</text>
              </svg>
            </div>
            <p className="mt-2 text-xs font-bold text-sky-500 font-mono">
              💡 Astuce : Passe ta souris sur les zones de terre ferme pour voir briller les frontières !
            </p>
          </div>

          {/* Cards Hub Section representing 7 Continents */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <span className="text-3xl">🌍</span>
              <div>
                <h3 className="text-2xl font-black text-slate-800 font-sans">
                  Parcours les 7 Continents
                </h3>
                <p className="text-sm text-slate-500 font-bold">Chacun a sa propre personnalité et ses merveilles !</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {CONTINENTS_DATA.map((continent) => (
                <motion.div
                  key={continent.id}
                  variants={itemVariants}
                  whileHover={{ scale: 1.03, y: -4 }}
                  onClick={() => handleContinentClick(continent)}
                  className={`cursor-pointer rounded-3xl p-6 border-4 shadow-sm flex flex-col justify-between transition-all duration-300 ${continent.color} ${continent.hoverColor}`}
                  id={`card-${continent.id}`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="text-4xl p-1 bg-white/60 rounded-full shadow-inner">{continent.illuSymbol}</span>
                      <span className="text-xs font-extrabold px-3 py-1 bg-white/70 rounded-full shadow-sm text-slate-800 tracking-wider font-mono">
                        {continent.countries.length} {continent.countries.length > 1 ? 'pays fiches' : 'pays fiche'}
                      </span>
                    </div>
                    <h4 className="text-xl font-black tracking-tight">{continent.name}</h4>
                    <span className="text-xs font-extrabold bg-white/30 px-2 py-0.5 rounded-md block w-fit mt-1 leading-normal italic opacity-95">
                      « {continent.slogan} »
                    </span>
                    <p className="mt-4 text-xs font-medium leading-relaxed opacity-90 text-slate-800">
                      {continent.description}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-black/5 flex items-center justify-between text-xs font-black">
                    <span className="underline">Explorer ce continent</span>
                    <span>🚀</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* 2. Focused Continent Subview (filters & yields countries) */}
      {focusedContinent && !focusedCountry && (
        <motion.div
          initial={{ opacity: 0, x: -15 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 15 }}
          className="space-y-8"
        >
          {/* Back btn */}
          <button
            onClick={clearSelection}
            className="flex items-center gap-2 px-5 py-2.5 bg-sky-100 text-sky-600 hover:bg-sky-200 font-bold text-sm rounded-full transition-all cursor-pointer shadow-3xs hover:scale-102"
            id="back-to-world-btn"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Retour à la carte du monde</span>
          </button>

          {/* Continent Hero Box matching Vibrant Palette style */}
          <div className={`p-6 sm:p-8 rounded-[2rem] border-4 shadow-md relative overflow-hidden ${focusedContinent.color}`}>
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_50%_120%,#ffffff_0%,transparent_50%)] pointer-events-none"></div>
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-5xl p-3 bg-white/70 rounded-3xl shrink-0 shadow-inner animate-wiggle">{focusedContinent.illuSymbol}</span>
                <div>
                  <span className="text-[10px] font-black tracking-widest uppercase font-mono bg-white/50 px-3 py-1 rounded-full text-slate-800">
                    Continent exploré
                  </span>
                  <h2 className="text-3xl font-black font-sans leading-none mt-2">{focusedContinent.name}</h2>
                </div>
              </div>
              <div className="md:text-right max-w-sm">
                <p className="text-xs font-black italic text-slate-800 bg-white/40 px-3 py-1.5 rounded-2xl block w-fit md:ml-auto">
                  « {focusedContinent.slogan} »
                </p>
              </div>
            </div>
            <p className="relative z-10 mt-4 text-xs sm:text-sm font-medium leading-relaxed max-w-3xl text-slate-850">
              {focusedContinent.description}
            </p>
          </div>

          {/* List Countries in focused Continent */}
          <div>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6" id="local-country-filter">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🗺️</span>
                <h3 className="text-xl font-black text-slate-800 font-sans">
                  Les pays de ce continent ({filteredCountries.length}) :
                </h3>
              </div>
              <div className="relative max-w-xs w-full">
                <input
                  type="text"
                  placeholder="🔎 Filtrer les pays ici..."
                  value={localSearchQuery}
                  onChange={(e) => setLocalSearchQuery(e.target.value)}
                  className="w-full px-4 py-2 text-sm bg-white rounded-full border-2 border-slate-200 outline-none focus:border-sky-300 font-medium text-slate-700 shadow-3xs transition-all"
                  id="explorer-local-search-input"
                />
                {localSearchQuery && (
                  <button
                    onClick={() => setLocalSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 font-bold text-xs"
                    title="Effacer le filtre"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            {filteredCountries.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-sky-50 rounded-[2rem] p-10 text-center border-4 border-dashed border-sky-100 text-sky-700 font-bold"
                id="no-countries-filter-card"
              >
                <div className="text-5xl mb-3 animate-bounce">🎈</div>
                <p className="text-lg">Oups ! Aucun pays n'a été trouvé avec « {localSearchQuery} »</p>
                <p className="text-xs text-sky-500 mt-2 font-medium">Essaie d'autres lettres pour découvrir la Terre !</p>
              </motion.div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCountries.map((country) => (
                  <motion.div
                    key={country.id}
                    whileHover={{ scale: 1.03, y: -4 }}
                    className="bg-white rounded-3xl border-4 border-slate-100 hover:border-sky-200 p-5 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between cursor-pointer"
                    onClick={() => onSelectCountry(country)}
                    id={`country-card-${country.id}`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3.5">
                        <span className="text-4xl bg-sky-50 p-2 rounded-2xl block w-fit shrink-0">{country.flag}</span>
                        <span className={`text-[11px] font-bold font-mono px-3 py-1 rounded-full border ${
                          country.landmarks && country.landmarks.length > 1
                            ? 'bg-amber-50 text-amber-800 border-amber-150'
                            : 'bg-emerald-50 text-emerald-800 border-emerald-150'
                        }`}>
                          {country.landmarks && country.landmarks.length > 1 ? 'Super Vedette 🌟' : 'Découverte 🧭'}
                        </span>
                      </div>

                      <h4 className="text-xl font-extrabold text-slate-800 font-sans">{country.name}</h4>
                      
                      <div className="mt-3.5 space-y-2 text-xs text-slate-600 font-medium">
                        <p className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-sky-500" />
                          <span>Capitale : <strong className="text-slate-800 font-black">{country.capital}</strong></span>
                        </p>
                        <p className="flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-sky-500" />
                          <span>Population : <strong className="text-slate-800 font-black">{country.population}</strong></span>
                        </p>
                        <p className="flex items-center gap-1.5">
                          <Award className="w-3.5 h-3.5 text-sky-500" />
                          <span>Monnaie : <strong className="text-slate-800 font-black">{country.currency}</strong></span>
                        </p>
                      </div>
                    </div>

                    <div className="mt-6 pt-3.5 border-t-2 border-slate-50 flex items-center justify-between text-xs font-black text-sky-600">
                      <span>Ouvrir l'encyclopédie</span>
                      <span>📚 🚀</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
}
