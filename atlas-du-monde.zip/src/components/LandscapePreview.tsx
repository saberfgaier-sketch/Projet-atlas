import React from 'react';

interface LandscapePreviewProps {
  countryId: string;
  name: string;
  illustrationDescription: string;
}

export default function LandscapePreview({ countryId, name, illustrationDescription }: LandscapePreviewProps) {
  // Render high quality mini vector scenes based on the country
  const renderVectorScene = () => {
    switch (countryId) {
      case 'france':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="paris-sky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fca5a5" /> {/* light red */}
                <stop offset="40%" stopColor="#fef08a" /> {/* light yellow */}
                <stop offset="100%" stopColor="#bae6fd" /> {/* light blue */}
              </linearGradient>
            </defs>
            {/* Sky */}
            <rect width="400" height="200" fill="url(#paris-sky)" />
            {/* Sun */}
            <circle cx="280" cy="80" r="25" fill="#fde047" opacity="0.8" />
            {/* Clouds */}
            <path d="M 30 60 Q 50 40 70 60 Q 90 40 110 60 T 140 60 L 140 70 L 30 70 Z" fill="white" opacity="0.6" />
            <path d="M 280 40 Q 295 25 310 40 Q 325 25 340 40 T 365 40 L 365 48 L 280 48 Z" fill="white" opacity="0.5" />
            {/* Rolling Hills / Cityscape line */}
            <path d="M0 160 Q80 150 160 160 T320 150 Q360 155 400 150 L400 200 L0 200 Z" fill="#65a30d" opacity="0.8" />
            <rect x="0" y="150" width="400" height="50" fill="#4d7c0f" />
            {/* Eiffel Tower Silhouette */}
            <g transform="translate(170, 30)" fill="#475569">
              {/* Base legs */}
              <path d="M 10 130 L 18 130 L 25 100 L 15 100 Z" />
              <path d="M 50 130 L 42 130 L 35 100 L 45 100 Z" />
              <path d="M 18 130 Q 30 110 42 130 Z" fill="#334155" /> {/* Arch */}
              {/* First Platform */}
              <rect x="15" y="95" width="30" height="6" rx="2" />
              {/* Second story */}
              <path d="M 17 95 L 22 60 L 38 60 L 43 95 Z" />
              <rect x="20" y="55" width="20" height="5" rx="1" />
              {/* Top spire */}
              <path d="M 23 55 L 27 10 L 33 10 L 37 55 Z" />
              <line x1="30" y1="10" x2="30" y2="0" stroke="#475569" strokeWidth="2" />
              {/* Beams detail */}
              <line x1="16" y1="95" x2="44" y2="55" stroke="#334155" strokeWidth="1" opacity="0.5" />
              <line x1="44" y1="95" x2="16" y2="55" stroke="#334155" strokeWidth="1" opacity="0.5" />
            </g>
            {/* Cute French café tables */}
            <rect x="25" y="155" width="20" height="15" fill="#f59e0b" rx="2" />
            <circle cx="15" cy="165" r="5" fill="#ef4444" />
            <circle cx="45" cy="165" r="5" fill="#3b82f6" />
          </svg>
        );
      case 'italie':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#fef08a" /> {/* soft yellow */}
            <circle cx="80" cy="70" r="35" fill="#f97316" opacity="0.6" /> {/* warm sun */}
            {/* Tuscan Green rolling hills */}
            <path d="M-50 140 Q100 80 250 130 T550 110 L550 200 L-50 200 Z" fill="#84cc16" />
            <path d="M100 160 Q220 120 320 160 T500 140 L500 200 L100 200 Z" fill="#22c55e" opacity="0.8" />
            {/* Pisa Tower tilted */}
            <g transform="translate(100, 45) rotate(6)" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1">
              {/* base */}
              <rect x="15" y="100" width="35" height="12" rx="1" fill="#cbd5e1" />
              {/* columns stories */}
              <rect x="17" y="82" width="31" height="18" />
              <rect x="18" y="66" width="29" height="16" />
              <rect x="19" y="50" width="27" height="16" />
              <rect x="20" y="34" width="25" height="16" />
              <rect x="21" y="18" width="23" height="16" />
              {/* bell top */}
              <path d="M22 18 L24 2 L30 2 L32 18 Z" fill="#94a3b8" />
              {/* Arches markings */}
              <line x1="20" y1="90" x2="45" y2="90" stroke="#475569" />
              <line x1="20" y1="74" x2="45" y2="74" stroke="#475569" />
              <line x1="22" y1="58" x2="43" y2="58" stroke="#475569" />
              <line x1="22" y1="42" x2="43" y2="42" stroke="#475569" />
            </g>
            {/* Colosseum silhouette */}
            <g transform="translate(240, 95)" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="1.5">
              <path d="M 0 50 L 0 10 Q 50 12 110 10 L 110 50 Z" fill="#e2e8f0" />
              <path d="M 12 10 Q 12 25 15 50" stroke="#64748b" />
              <path d="M 40 10 Q 40 25 40 50" stroke="#64748b" />
              <path d="M 70 10 Q 70 25 70 50" stroke="#64748b" />
              <path d="M 95 10 Q 95 25 95 50" stroke="#64748b" />
              {/* arches holes */}
              <rect x="20" y="20" width="10" height="15" rx="4" fill="#64748b" />
              <rect x="50" y="20" width="10" height="15" rx="4" fill="#64748b" />
              <rect x="80" y="20" width="10" height="15" rx="4" fill="#64748b" />
            </g>
            {/* Cypress tree */}
            <path d="M 40 180 L 42 120 L 45 180 Z" stroke="#14532d" strokeWidth="6" />
            <path d="M 310 170 L 312 110 L 316 170 Z" stroke="#14532d" strokeWidth="8" />
          </svg>
        );
      case 'espagne':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#ffedd5" /> {/* Light orange sand */}
            <circle cx="340" cy="50" r="40" fill="#ea580c" opacity="0.8" /> {/* Intense sunset sun */}
            {/* Mosaic hills */}
            <path d="M0 150 Q120 180 240 145 T480 160 L480 200 L0 200 Z" fill="#fdba74" />
            <path d="M-40 170 Q100 130 280 175 T500 150 L500 200 L-40 200 Z" fill="#ca8a04" opacity="0.6" />
            {/* Sagrada Familia Towers */}
            <g transform="translate(140, 40)" fill="#7c2d12" opacity="0.9">
              {/* Spire 1 */}
              <path d="M 15 130 L 25 20 L 35 130 Z" />
              <circle cx="25" cy="15" r="4" fill="#f59e0b" />
              {/* Spire 2 */}
              <path d="M 40 130 L 50 10 L 60 130 Z" />
              <circle cx="50" cy="5" r="4" fill="#ef4444" />
              {/* Spire 3 */}
              <path d="M 65 130 L 75 30 L 85 130 Z" />
              <circle cx="75" cy="25" r="4" fill="#3b82f6" />
              {/* connecting bridge arches */}
              <rect x="25" y="60" width="40" height="15" fill="#9a3412" opacity="0.7" />
              <rect x="30" y="80" width="30" height="15" fill="#9a3412" opacity="0.7" />
            </g>
            {/* Orange Tree */}
            <circle cx="60" cy="140" r="20" fill="#15803d" />
            <rect x="57" y="155" width="6" height="20" fill="#78350f" />
            <circle cx="52" cy="132" r="4" fill="#f97316" />
            <circle cx="68" cy="138" r="4" fill="#f97316" />
            <circle cx="60" cy="145" r="4" fill="#f97316" />
          </svg>
        );
      case 'japon':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Sky */}
            <rect width="400" height="200" fill="#fce7f3" /> {/* Soft pink morning sky */}
            {/* Big Red Sun - Hinomaru style */}
            <circle cx="200" cy="110" r="55" fill="#ef4444" />
            {/* Mount Fuji shape */}
            <path d="M 80 200 L 170 80 Q 200 65 230 80 L 320 200 Z" fill="#1e3a8a" />
            {/* Snowcap on Mount Fuji */}
            <path d="M 170 80 Q 200 65 230 80 L 250 110 L 235 115 L 220 105 L 200 120 L 180 105 L 165 115 Z" fill="white" />
            {/* Soft fog / lake at base */}
            <ellipse cx="200" cy="195" rx="220" ry="12" fill="#93c5fd" opacity="0.7" />
            {/* Traditional Torii Gate silhouette on the side */}
            <g transform="translate(40, 130)" fill="#b91c1c">
              <rect x="10" y="5" width="50" height="7" rx="1" /> {/* top beam */}
              <rect x="5" y="0" width="60" height="6" rx="1.5" /> {/* double top */}
              <rect x="15" y="10" width="40" height="5" /> {/* tie beam */}
              <rect x="18" y="5" width="6" height="55" /> {/* pillar left */}
              <rect x="46" y="5" width="6" height="55" /> {/* pillar right */}
            </g>
            {/* Hanging Cherry Blossom branches (Sakura) */}
            <g transform="translate(280, 5)" stroke="#78350f" strokeWidth="2">
              <path d="M 120 10 Q 60 20 0 50" fill="none" />
              <path d="M 80 15 Q 40 35 20 70" fill="none" />
              {/* flowers */}
              <circle cx="40" cy="23" r="6" fill="#fbcfe8" stroke="none" />
              <circle cx="40" cy="23" r="2" fill="#db2777" stroke="none" />
              <circle cx="10" cy="48" r="7" fill="#fbcfe8" stroke="none" />
              <circle cx="10" cy="48" r="2" fill="#db2777" stroke="none" />
              <circle cx="65" cy="19" r="6" fill="#fbcfe8" stroke="none" />
            </g>
          </svg>
        );
      case 'inde':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Sky gradient */}
            <defs>
              <linearGradient id="india-sky" x1="0" y1="0" x2="0" y2="100%">
                <stop offset="0%" stopColor="#fdba74" />
                <stop offset="60%" stopColor="#fef08a" />
                <stop offset="100%" stopColor="#bae6fd" />
              </linearGradient>
            </defs>
            <rect width="400" height="200" fill="url(#india-sky)" />
            {/* Giant soft palace reflection */}
            <rect x="0" y="170" width="400" height="30" fill="#38bdf8" />
            <line x1="0" y1="170" x2="400" y2="170" stroke="#0284c7" strokeWidth="3" />
            {/* Taj Mahal intricate layout */}
            <g transform="translate(90, 55)" fill="#f8fafc" stroke="#e2e8f0" strokeWidth="0.5">
              {/* Main base */}
              <rect x="30" y="80" width="160" height="35" rx="1" />
              {/* Main grand dome */}
              <path d="M 90 80 Q 90 40 110 32 Q 130 40 130 80 Z" />
              <circle cx="110" cy="30" r="2" fill="#e2e8f0" />
              <line x1="110" y1="30" x2="110" y2="20" stroke="#cbd5e1" strokeWidth="1.5" />
              {/* Left small dome */}
              <path d="M 60 80 Q 60 60 70 55 Q 80 60 80 80 Z" />
              {/* Right small dome */}
              <path d="M 140 80 Q 140 60 150 55 Q 160 60 160 80 Z" />
              {/* Center giant archway portal */}
              <rect x="92" y="55" width="36" height="25" rx="1" fill="#f1f5f9" />
              <path d="M 98 80 L 98 62 C 98 55 122 55 122 62 L 122 80 Z" fill="#e2e8f0" />
              {/* Minaret Left */}
              <rect x="10" y="30" width="10" height="85" />
              <path d="M 7 30 Q 7 24 15 24 Q 23 24 23 30 Z" fill="#cbd5e1" />
              {/* Minaret Right */}
              <rect x="200" y="30" width="10" height="85" />
              <path d="M 197 30 Q 197 24 205 24 Q 213 24 213 30 Z" fill="#cbd5e1" />
            </g>
            {/* Silhouette of cute decorated elephant in the foreground */}
            <g transform="translate(10, 110) scale(0.65)" fill="#475569">
              {/* body */}
              <rect x="20" y="35" width="60" height="40" rx="15" />
              {/* head */}
              <circle cx="20" cy="35" r="16" />
              {/* legs */}
              <rect x="27" y="65" width="10" height="25" rx="2" />
              {/* back leg */}
              <rect x="63" y="65" width="10" height="25" rx="2" />
              {/* trunk */}
              <path d="M 8 35 Q -6 35 -4 55 Q -2 60 4 60" stroke="#475569" strokeWidth="6" strokeLinecap="round" fill="none" />
              {/* saddle cloth */}
              <rect x="35" y="35" width="30" height="25" fill="#ef4444" rx="3" />
              <rect x="40" y="38" width="20" height="20" fill="#fbbf24" rx="2" />
            </g>
          </svg>
        );
      case 'chine':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#ecfdf5" /> {/* Light teal sky */}
            {/* Mist effect */}
            <ellipse cx="200" cy="110" rx="180" ry="25" fill="#f0fdf4" opacity="0.8" />
            {/* Sinous hills behind */}
            <path d="M 0 160 Q 90 110 180 140 T 360 110 T 450 150 L 450 200 L 0 200 Z" fill="#34d399" opacity="0.6" />
            <path d="M -50 170 Q 100 130 250 160 T 550 140 L 550 200 L -50 200 Z" fill="#059669" />
            {/* Great Wall trail */}
            <path d="M 0 175 Q 85 130 180 155 T 380 120" stroke="#d97706" strokeWidth="8" fill="none" strokeLinecap="round" />
            <path d="M 0 175 Q 85 130 180 155 T 380 120" stroke="#fef08a" strokeWidth="2" fill="none" strokeDasharray="4 4" />
            {/* Watchtower */}
            <g transform="translate(190, 115)" fill="#b45309" stroke="#78350f" strokeWidth="1">
              <rect x="0" y="15" width="40" height="30" />
              {/* battlements */}
              <rect x="-2" y="8" width="44" height="7" fill="#92400e" />
              <rect x="2" y="2" width="6" height="6" />
              <rect x="12" y="2" width="6" height="6" />
              <rect x="22" y="2" width="6" height="6" />
              <rect x="32" y="2" width="6" height="6" />
              {/* arched door */}
              <rect x="14" y="24" width="12" height="21" rx="4" fill="#334155" />
            </g>
            {/* Cute panda peeking with green bamboo */}
            <g transform="translate(20, 130) scale(0.8)">
              {/* Bamboo staff */}
              <line x1="300" y1="50" x2="310" y2="-10" stroke="#16a34a" strokeWidth="5" />
              <line x1="312" y1="40" x2="330" y2="25" stroke="#16a34a" strokeWidth="3" />
              {/* panda head */}
              <circle cx="270" cy="40" r="16" fill="white" stroke="#1e293b" strokeWidth="1.5" />
              {/* ears */}
              <circle cx="256" cy="26" r="6" fill="#1e293b" />
              <circle cx="284" cy="26" r="6" fill="#1e293b" />
              {/* eye patches */}
              <ellipse cx="264" cy="38" rx="4" ry="5" fill="#1e293b" />
              <ellipse cx="276" cy="38" rx="4" ry="5" fill="#1e293b" />
              <circle cx="265" cy="37" r="1" fill="white" />
              <circle cx="275" cy="37" r="1" fill="white" />
              <circle cx="270" cy="45" r="2" fill="#1e293b" /> {/* nose */}
            </g>
          </svg>
        );
      case 'maroc':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Sunset gradient sky */}
            <defs>
              <linearGradient id="maroc-sky" x1="0" y1="0" x2="0" y2="100%">
                <stop offset="0%" stopColor="#7c3aed" /> {/* violet */}
                <stop offset="50%" stopColor="#db2777" /> {/* pink */}
                <stop offset="100%" stopColor="#f97316" /> {/* orange */}
              </linearGradient>
            </defs>
            <rect width="400" height="200" fill="url(#maroc-sky)" />
            {/* Sparkly stars */}
            <circle cx="80" cy="30" r="1.5" fill="white" opacity="0.9" />
            <circle cx="150" cy="45" r="1" fill="white" opacity="0.7" />
            <circle cx="240" cy="25" r="1.5" fill="white" opacity="0.9" />
            <circle cx="320" cy="40" r="1" fill="white" opacity="0.8" />
            {/* Crescent Moon */}
            <path d="M 330 20 Q 315 20 315 35 Q 315 50 330 50 Q 340 50 345 42 Q 330 42 328 35 Q 326 28 338 23 Z" fill="#fef08a" />
            {/* Golden Sahara Dunes */}
            <path d="M-50 160 Q100 110 250 170 T550 150 L550 200 L-50 200 Z" fill="#fbbf24" />
            <path d="M100 180 Q220 140 320 185 T500 165 L500 200 L100 200 Z" fill="#f59e0b" />
            <path d="M-80 190 Q80 135 200 180 Q300 150 420 190 L420 200 L-80 200 Z" fill="#d97706" opacity="0.9" />
            {/* Camel silhouette caravan */}
            <g transform="translate(140, 140) scale(0.65)" fill="#451a03">
              {/* hump */}
              <circle cx="45" cy="20" r="8" />
              {/* body */}
              <rect x="25" y="24" width="40" height="15" rx="5" />
              {/* neck */}
              <path d="M 27 28 Q 18 20 18 10" stroke="#451a03" strokeWidth="5" strokeLinecap="round" />
              {/* head */}
              <rect x="12" y="4" width="12" height="7" rx="2" />
              {/* legs */}
              <rect x="29" y="38" width="3" height="18" />
              <rect x="36" y="38" width="3" height="18" />
              <rect x="54" y="38" width="3" height="18" />
              <rect x="61" y="38" width="3" height="18" />
            </g>
            {/* Palm Tree */}
            <g transform="translate(40, 100)">
              <path d="M 15 80 Q 8 40 10 0" stroke="#78350f" strokeWidth="5" fill="none" />
              {/* Leaves */}
              <path d="M 10 0 Q -10 -15 -25 -10" stroke="#15803d" strokeWidth="4" fill="none" strokeLinecap="round" />
              <path d="M 10 0 Q -5 -25 15 -35" stroke="#15803d" strokeWidth="4" fill="none" strokeLinecap="round" />
              <path d="M 10 0 Q 25 -25 35 -15" stroke="#15803d" strokeWidth="4" fill="none" strokeLinecap="round" />
              <path d="M 10 0 Q 30 -5 40 10" stroke="#15803d" strokeWidth="4" fill="none" strokeLinecap="round" />
            </g>
          </svg>
        );
      case 'egypte':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#fef08a" /> {/* Blazing yellow sky */}
            {/* Sun */}
            <circle cx="200" cy="55" r="28" fill="#f97316" />
            {/* Pyramids */}
            <g transform="translate(45, 110)">
              {/* Big Pyramid Gizeh */}
              <polygon points="120,80 200,0 280,80" fill="#eab308" stroke="#ca8a04" strokeWidth="1" />
              {/* Shadow facet */}
              <polygon points="200,80 200,0 280,80" fill="#ca8a04" opacity="0.3" />

              {/* Second Pyramid */}
              <polygon points="30,80 95,15 160,80" fill="#f1c40f" stroke="#ca8a04" strokeWidth="1" />
              <polygon points="95,80 95,15 160,80" fill="#d4ac0d" opacity="0.3" />

              {/* Small Pyramid */}
              <polygon points="250,80 290,35 330,80" fill="#fbbf24" stroke="#ca8a04" strokeWidth="1" />
              <polygon points="290,80 290,35 330,80" fill="#f59e0b" opacity="0.3" />
            </g>
            {/* Ground */}
            <rect x="0" y="180" width="400" height="20" fill="#eab308" />
            {/* Cute Sphinx outline left */}
            <g transform="translate(15, 145) scale(0.6)" fill="#b45309">
              {/* head */}
              <rect x="10" y="5" width="22" height="22" rx="4" />
              {/* head dress */}
              <path d="M 4 5 L 38 5 L 34 22 L 30 27 L 12 27 L 8 22 Z" fill="#78350f" />
              {/* body lion */}
              <rect x="25" y="18" width="55" height="25" rx="5" />
              {/* paws */}
              <rect x="25" y="38" width="45" height="10" rx="3" fill="#b45309" />
              <circle cx="20" cy="15" r="2" fill="#eab308" /> {/* eye */}
            </g>
          </svg>
        );
      case 'afrique_sud':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#e0f2fe" /> {/* Blue coastal sky */}
            {/* Table Mountain Silhouette */}
            <path d="M0 130 L100 130 L130 90 L270 90 L300 130 L400 130 L400 200 L0 200 Z" fill="#475569" />
            <path d="M120 90 Q200 85 280 90 C290 90 290 96 280 96 L120 96 Z" fill="white" opacity="0.8" /> {/* Cloud tablecloth */}
            {/* Sandy coast foreground */}
            <path d="M-20 170 Q130 150 250 180 T450 170 L450 200 L-20 200 Z" fill="#fef08a" />
            {/* Ocean Waves */}
            <path d="M 0 150 Q 80 140 160 150 T 320 145 T 400 150 L 400 175 L 0 175 Z" fill="#0284c7" opacity="0.4" />
            {/* Penguins on the beach Boulders */}
            <g transform="translate(60, 155) scale(0.5)">
              {/* Penguin 1 */}
              <ellipse cx="20" cy="40" rx="10" ry="18" fill="black" />
              <ellipse cx="20" cy="42" rx="6" ry="12" fill="white" />
              <ellipse cx="24" cy="32" rx="2" ry="3" fill="orange" /> {/* beak */}
              <circle cx="17" cy="28" r="1.5" fill="white" /> {/* eye */}
              <circle cx="17" cy="28" r="0.7" fill="black" />
            </g>
            <g transform="translate(140, 160) scale(0.45)">
              {/* Penguin 2 looking right */}
              <ellipse cx="20" cy="40" rx="10" ry="18" fill="black" />
              <ellipse cx="20" cy="42" rx="6" ry="12" fill="white" />
              <ellipse cx="24" cy="32" rx="2" ry="3" fill="orange" />
              <circle cx="17" cy="28" r="1.5" fill="white" />
            </g>
            {/* Protea Red Flower */}
            <circle cx="340" cy="170" r="12" fill="#ec4899" />
            <circle cx="340" cy="170" r="7" fill="#f43f5e" />
            <rect x="338" y="177" width="4" height="25" fill="#15803d" />
          </svg>
        );
      case 'canada':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#ecfeff" /> {/* Light glacial sky */}
            {/* Pine forest in the background */}
            <polygon points="40,150 60,80 80,150" fill="#14532d" />
            <polygon points="65,160 85,90 105,160" fill="#15803d" />
            <polygon points="15,165 30,105 45,165" fill="#0f291b" />
            <polygon points="320,150 340,90 360,150" fill="#15803d" />
            {/* Rock mountains with snow heights */}
            <path d="M 80 150 L 180 50 L 230 110 L 290 40 L 370 150 Z" fill="#94a3b8" />
            <path d="M 160 70 L 180 50 L 200 70 L 190 75 L 180 68 L 170 75 Z" fill="white" />
            <path d="M 270 63 L 290 40 L 310 63 L 300 68 L 290 60 L 280 68 Z" fill="white" />
            {/* Great Turquoise lake */}
            <path d="M 0 140 Q 100 130 200 138 T 400 135 L 400 200 L 0 200 Z" fill="#06b6d4" />
            {/* red canoe */}
            <path d="M 120 165 C 130 172 170 172 180 165 C 175 160 125 160 120 165 Z" fill="#ef4444" />
            {/* maple leaf watermark bottom-right */}
            <g transform="translate(340, 140) scale(0.65)" opacity="0.8" fill="#b91c1c">
              <path d="M 20 0 L 23 10 L 33 5 L 30 15 L 40 15 L 32 22 L 36 32 L 25 27 L 27 38 L 20 38 L 20 48 L 18 48 L 18 38 L 11 38 L 13 27 L 2 32 L 6 22 L -2 15 L 8 15 L 5 5 L 15 10 Z" />
            </g>
          </svg>
        );
      case 'usa':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Sunset sky */}
            <defs>
              <linearGradient id="usa-sky" x1="0" y1="0" x2="0" y2="100%">
                <stop offset="0%" stopColor="#1e3a8a" />
                <stop offset="60%" stopColor="#701a75" />
                <stop offset="100%" stopColor="#f43f5e" />
              </linearGradient>
            </defs>
            <rect width="400" height="200" fill="url(#usa-sky)" />
            {/* Statue of Liberty left */}
            <g transform="translate(45, 30)" fill="#a7f3d0" stroke="#047857" strokeWidth="0.5">
              {/* Pedestal */}
              <rect x="5" y="110" width="30" height="30" fill="#94a3b8" stroke="none" />
              <rect x="0" y="130" width="40" height="15" fill="#64748b" stroke="none" />
              {/* Body */}
              <path d="M 12 110 L 28 110 L 25 50 L 15 50 Z" />
              {/* head with crown */}
              <circle cx="20" cy="45" r="5" />
              <path d="M 15 42 L 25 42 L 22 45 L 18 45 Z" />
              <polygon points="15,40 13,44 18,43" />
              <polygon points="20,38 20,42 22,40" />
              <polygon points="25,40 27,44 22,43" />
              {/* Torch arm raised */}
              <path d="M 24 55 Q 32 40 32 25" stroke="#a7f3d0" strokeWidth="4" strokeLinecap="round" fill="none" />
              <circle cx="32" cy="22" r="3" fill="#f59e0b" stroke="none" /> {/* fire */}
              {/* Tablet arm */}
              <path d="M 14 60 L 8 70 L 12 73 Z" />
            </g>
            {/* Brooklyn bridge lines right */}
            <g transform="translate(180, 80)" fill="none" stroke="#e2e8f0" strokeWidth="1.5">
              {/* pillars */}
              <rect x="30" y="20" width="10" height="70" fill="#475569" stroke="none" />
              <rect x="120" y="20" width="10" height="70" fill="#475569" stroke="none" />
              {/* cables */}
              <path d="M 0 45 Q 35 25 80 50 Q 125 25 160 45" />
              <path d="M 35 20 Q 75 70 125 20" />
            </g>
            <rect x="150" y="150" width="250" height="50" fill="#1e293b" opacity="0.9" /> {/* cityscape dark block */}
            <rect x="190" y="110" width="25" height="40" fill="#1e293b" />
            <rect x="250" y="90" width="35" height="60" fill="#1e293b" />
            <rect x="310" y="120" width="20" height="30" fill="#1e293b" />
            {/* window dots */}
            <circle cx="260" cy="110" r="1.5" fill="#fef08a" />
            <circle cx="270" cy="110" r="1.5" fill="#fef08a" />
            <circle cx="260" cy="130" r="1.5" fill="#fef08a" />
            <circle cx="270" cy="130" r="1.5" fill="#fef08a" />
          </svg>
        );
      case 'mexique':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#fff7ed" /> {/* desert warm sky */}
            <circle cx="260" cy="70" r="30" fill="#f97316" /> {/* sun */}
            {/* Chichen Itza Aztec pyramid */}
            <g transform="translate(100, 70)" fill="#d97706" stroke="#b45309" strokeWidth="0.5">
              {/* steps base */}
              <polygon points="0,110 30,85 170,85 200,110" />
              <polygon points="15,85 45,60 155,60 185,85" />
              <polygon points="30,60 55,35 145,35 170,60" />
              {/* top shrine */}
              <rect x="75" y="15" width="50" height="20" fill="#b45309" />
              {/* center stair pathway */}
              <polygon points="85,110 90,15 110,15 115,110" fill="#92400e" stroke="none" />
            </g>
            {/* Desert soil with warm dunes */}
            <path d="M 0 170 Q 120 150 250 175 T 450 165 L 450 200 L 0 200 Z" fill="#ca8a04" opacity="0.4" />
            <rect x="0" y="180" width="400" height="20" fill="#854d0e" />
            {/* Saguaro cactus outline */}
            <g transform="translate(30, 110)" fill="#15803d">
              {/* trunk */}
              <rect x="15" y="0" width="8" height="70" rx="3" />
              {/* left branch */}
              <path d="M 15 35 L 5 35 L 5 15 L 11 15 L 11 29 L 15 29 Z" />
              {/* right branch */}
              <path d="M 23 25 L 33 25 L 33 5 L 27 5 L 27 19 L 23 19 Z" />
            </g>
            {/* Sombrero hat decoration lower-right */}
            <g transform="translate(320, 155) scale(0.7)" fill="#ea580c">
              <path d="M 10 25 C 10 12 50 12 50 25 Z" /> {/* top */}
              <ellipse cx="30" cy="25" rx="35" ry="8" /> {/* brim */}
              <ellipse cx="30" cy="25" rx="35" ry="3" fill="#fbbf24" md="true" /> {/* ribbon */}
            </g>
          </svg>
        );
      case 'bresil':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#bae6fd" /> {/* bright bay blue sky */}
            {/* Corcovado mountain peaks */}
            <path d="M 120 200 L 180 50 Q 200 40 220 50 L 280 200 Z" fill="#15803d" />
            <path d="M 40 200 L 90 120 Q 110 115 125 122 L 180 200 Z" fill="#166534" />
            <path d="M 240 200 L 290 100 Q 310 95 330 110 L 380 200 Z" fill="#166534" />
            {/* Christ Redemptor peak silhouette */}
            <g transform="translate(180, 23)" fill="#e2e8f0">
              <rect x="18" y="10" width="5" height="20" rx="1" id="christ-body" />
              <line x1="5" y1="14" x2="36" y2="14" stroke="#e2e8f0" strokeWidth="4.5" strokeLinecap="round" id="christ-arms" />
              <circle cx="20.5" cy="5.5" r="3.5" id="christ-head" />
            </g>
            {/* Copacabana waves sand beach foreground */}
            <path d="M-20 170 Q100 150 220 175 T450 165 L450 200 L-20 200 Z" fill="#fef08a" />
            {/* Wave drawing texture on the beach */}
            <path d="M0 175 Q40 168 80 175 T160 175 T240 175 T320 175 T400 175" stroke="#0284c7" strokeWidth="2" fill="none" opacity="0.4" />
            {/* Tucan parrot colorful silhouette */}
            <g transform="translate(30, 130) scale(0.65)">
              <ellipse cx="20" cy="30" rx="10" ry="18" fill="#1e293b" /> {/* body */}
              <path d="M 22 15 Q 38 12 36 24 L 22 24 Z" fill="#fbbf24" /> {/* beak */}
              <circle cx="16" cy="20" r="2" fill="white" />
              <path d="M 20 48 Q 25 55 22 65" stroke="#ef4444" strokeWidth="4" /> {/* tail */}
            </g>
          </svg>
        );
      case 'perou':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#ecfdf5" /> {/* Fresh green valley sky */}
            {/* High Cordillera Mountains */}
            <path d="M 40 200 L 140 40 L 220 150 L 310 30 L 400 200 Z" fill="#047857" />
            {/* Machu Picchu ruins terrace tiers */}
            <g fill="#059669" stroke="#065f46" strokeWidth="1">
              <polygon points="110,140 290,140 270,150 90,150" />
              <polygon points="120,150 270,150 250,162 100,162" />
              <polygon points="130,162 250,162 230,175 110,175" />
              <polygon points="140,175 230,175 210,188 120,188" />
            </g>
            {/* Inca houses outlines */}
            <rect x="150" y="125" width="15" height="15" fill="#f1f5f9" stroke="#94a3b8" />
            <polygon points="147,125 157.5,115 168,125" fill="#78350f" />
            <rect x="210" y="125" width="18" height="15" fill="#f1f5f9" stroke="#94a3b8" />
            <polygon points="207,125 219,115 231,125" fill="#78350f" />
            {/* Cute Lama peeking close-up from the bottom-left */}
            <g transform="translate(10, 110) scale(0.95)">
              {/* long neck */}
              <rect x="15" y="20" width="12" height="60" fill="#f8fafc" rx="4" id="lama-neck" />
              {/* head */}
              <rect x="15" y="8" width="22" height="14" fill="#f8fafc" rx="3" id="lama-head" />
              {/* long ears */}
              <rect x="17" y="0" width="4" height="10" fill="#f1f5f9" rx="1" />
              <rect x="25" y="0" width="4" height="10" fill="#f1f5f9" rx="1" />
              {/* eye */}
              <circle cx="28" cy="13" r="1.8" fill="black" />
              {/* muzzle */}
              <rect x="31" y="14" width="8" height="6" fill="#cbd5e1" rx="1.5" />
              {/* pink cheeks */}
              <circle cx="22" cy="18" r="1.5" fill="#f472b6" />
            </g>
          </svg>
        );
      case 'australie':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#f0f9ff" /> {/* light ocean blue sky */}
            {/* Sun */}
            <circle cx="330" cy="50" r="22" fill="#eab308" opacity="0.8" />
            {/* Blue Sea */}
            <rect x="0" y="130" width="400" height="70" fill="#0284c7" />
            <path d="M 0 130 Q 80 120 160 130 T 320 125 T 400 130 L 400 145 L 0 145 Z" fill="#0369a1" />
            {/* Sydney Opera House White Sails inside the harbor */}
            <g transform="translate(45, 75)" fill="#f8fafc" stroke="#e2e8f0" strokeWidth="1">
              {/* sail 1 */}
              <path d="M 10 55 C 10 20 40 25 50 55 Z" />
              {/* sail 2 */}
              <path d="M 35 55 C 35 10 75 12 85 55 Z" />
              {/* sail 3 offset */}
              <path d="M 70 55 C 70 20 100 22 110 55 Z" />
              {/* base platform */}
              <rect x="0" y="52" width="130" height="6" fill="#cbd5e1" />
            </g>
            {/* Kangaroo jumping silhouette on land right side */}
            <g transform="translate(260, 90) scale(0.85)" fill="#b45309">
              {/* trail / tail */}
              <path d="M 60 45 Q 75 45 70 30" stroke="#b45309" strokeWidth="4.5" strokeLinecap="round" fill="none" />
              {/* body */}
              <rect x="30" y="20" width="30" height="18" rx="5" transform="rotate(-20 30 20)" />
              {/* long feet */}
              <rect x="33" y="32" width="6" height="25" rx="1" id="k-leg" />
              <rect x="42" y="32" width="6" height="25" rx="1" />
              {/* cute head with tall ears */}
              <ellipse cx="28" cy="10" rx="6" ry="9" />
              <rect x="23" y="1" width="3" height="8" rx="1" />
              <rect x="29" y="1" width="3" height="8" rx="1" />
              {/* small front claws */}
              <rect x="18" y="20" width="10" height="4" rx="1" />
            </g>
            {/* coral branches in water bottom-right */}
            <path d="M 370 200 Q 365 170 360 155" stroke="#f43f5e" strokeWidth="4" strokeLinecap="round" />
            <path d="M 363 175 Q 350 170 345 162" stroke="#f43f5e" strokeWidth="3.5" strokeLinecap="round" />
          </svg>
        );
      case 'nz':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#f0fdf4" /> {/* soft fresh green sky */}
            {/* Rolling green hills of Hobbiton */}
            <path d="M-50 140 Q100 70 250 135 T550 110 L550 200 L-50 200 Z" fill="#4ade80" />
            <path d="M100 150 Q220 110 320 155 T500 130 L500 200 L100 200 Z" fill="#22c55e" />
            {/* Hobbit hole built into the hill front center */}
            <g transform="translate(170, 115)">
              {/* arch dirt surround */}
              <path d="M 10 50 A 25 25 0 0 1 60 50 Z" fill="#b45309" stroke="#78350f" strokeWidth="2" />
              {/* green round door */}
              <path d="M 15 50 A 20 20 0 0 1 55 50 Z" fill="#16a34a" />
              {/* yellow doorknob in exact center */}
              <circle cx="35" cy="40" r="2.5" fill="#f59e0b" />
              {/* small window right */}
              <circle cx="75" cy="45" r="7" fill="#fbcfe8" stroke="#78350f" strokeWidth="1.5" />
              <circle cx="75" cy="45" r="5" fill="#fef08a" />
              {/* window panes frame */}
              <line x1="70" y1="45" x2="80" y2="45" stroke="#78350f" />
              <line x1="75" y1="40" x2="75" y2="50" stroke="#78350f" />
            </g>
            {/* Wild volcanic boiler cloud steam line on background */}
            <path d="M 320 110 C 310 90 350 80 340 60 C 330 40 370 30 360 10" stroke="white" strokeWidth="8" strokeLinecap="round" opacity="0.6" fill="none" />
            {/* Cute Kiwi bird standing bottom-left */}
            <g transform="translate(30, 130) scale(0.7)">
              {/* round brown body */}
              <ellipse cx="40" cy="45" rx="16" ry="14" fill="#7c2d12" />
              {/* beak - very long and narrow */}
              <line x1="24" y1="42" x2="3" y2="42" stroke="#d97706" strokeWidth="2.5" strokeLinecap="round" />
              {/* eyes */}
              <circle cx="30" cy="38" r="1.5" fill="black" />
              {/* small feet */}
              <line x1="36" y1="59" x2="33" y2="70" stroke="#d97706" strokeWidth="3" />
              <line x1="44" y1="59" x2="47" y2="70" stroke="#d97706" strokeWidth="3" />
            </g>
          </svg>
        );
      case 'base_amundsen':
        return (
          <svg className="w-full h-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="400" height="200" fill="#030712" /> {/* Polar night sky */}
            {/* Glowing Aurora Australe curtain */}
            <path d="M 10 100 Q 110 20 200 80 T 390 40" stroke="#22c55e" strokeWidth="15" fill="none" strokeLinecap="round" opacity="0.4" />
            <path d="M 10 100 Q 110 20 200 80 T 390 40" stroke="#4ade80" strokeWidth="6" fill="none" strokeLinecap="round" opacity="0.7" />
            <path d="M 30 110 Q 140 40 220 90 T 370 50" stroke="#3b82f6" strokeWidth="8" fill="none" strokeLinecap="round" opacity="0.4" id="aurora-blue" />
            {/* Stars */}
            <circle cx="50" cy="30" r="1" fill="white" />
            <circle cx="120" cy="40" r="1.5" fill="white" />
            <circle cx="280" cy="25" r="1" fill="white" />
            <circle cx="340" cy="60" r="1.5" fill="white" />
            {/* Infinite Ice sheet banquise */}
            <rect x="0" y="140" width="400" height="60" fill="#f1f5f9" />
            <path d="M 0 140 Q 150 135 400 140 L 400 150 L 0 150 Z" fill="#cbd5e1" opacity="0.5" />
            {/* Base Amundsen Scott on metal pillars */}
            <g transform="translate(190, 95)" fill="#ef4444" stroke="#78350f" strokeWidth="0.5">
              {/* main capsule box */}
              <rect x="10" y="15" width="80" height="30" rx="3" fill="#dc2626" stroke="none" />
              {/* laboratory dome roof */}
              <path d="M 35 15 A 15 15 0 0 1 65 15 Z" fill="#64748b" stroke="none" />
              {/* metal support columns */}
              <line x1="20" y1="45" x2="20" y2="60" stroke="#475569" strokeWidth="3" />
              <line x1="35" y1="45" x2="35" y2="60" stroke="#475569" strokeWidth="3" />
              <line x1="65" y1="45" x2="65" y2="60" stroke="#475569" strokeWidth="3" />
              <line x1="80" y1="45" x2="80" y2="60" stroke="#475569" strokeWidth="3" />
              {/* glowing yellow window dots */}
              <circle cx="30" cy="25" r="1.5" fill="#fef08a" stroke="none" />
              <circle cx="50" cy="25" r="1.5" fill="#fef08a" stroke="none" />
              <circle cx="70" cy="25" r="1.5" fill="#fef08a" stroke="none" />
            </g>
            {/* South Pole indicator post nearby */}
            <g transform="translate(120, 125)">
              <line x1="10" y1="0" x2="10" y2="35" stroke="#78350f" strokeWidth="3" />
              <circle cx="10" cy="0" r="5" fill="#ef4444" /> {/* mirror sphere */}
              <rect x="0" y="8" width="20" height="6" fill="#3b82f6" />
              <rect x="0" y="15" width="20" height="6" fill="#ffffff" />
            </g>
            {/* cute little penguin baby slide */}
            <g transform="translate(25, 142) scale(0.4)" fill="black">
              <ellipse cx="20" cy="30" rx="10" ry="16" />
              <ellipse cx="20" cy="32" rx="6" ry="10" fill="white" />
              <circle cx="16" cy="22" r="1.2" fill="white" />
              <ellipse cx="24" cy="26" rx="2.5" ry="1.5" fill="orange" />
            </g>
          </svg>
        );
      default:
        return (
          <div className="w-full h-full bg-slate-100 flex items-center justify-center border-2 border-dashed border-slate-300 rounded-xl" id="vector-scene-fallback">
            <span className="text-4xl text-slate-400">🏞️</span>
          </div>
        );
    }
  };

  return (
    <div className="relative overflow-hidden rounded-2xl border-4 border-amber-100 shadow-md bg-white">
      <div className="aspect-[2/1] w-full max-h-56 relative bg-slate-50">
        {renderVectorScene()}
      </div>
      <div className="bg-amber-50/70 p-3 border-t-2 border-amber-100/60 flex items-start gap-2.5">
        <span className="text-xl">📸</span>
        <div className="text-left">
          <h4 className="text-xs font-bold text-amber-900 leading-tight">Illustration interactive : {name}</h4>
          <p className="text-[11px] text-amber-800/80 leading-normal mt-0.5">{illustrationDescription}</p>
        </div>
      </div>
    </div>
  );
}
