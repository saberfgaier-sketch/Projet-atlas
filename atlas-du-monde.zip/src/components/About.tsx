import React from 'react';
import { Compass, BookOpen, Trophy, Sparkles, Globe, Heart } from 'lucide-react';

export default function About() {
  return (
    <div className="max-w-3xl mx-auto bg-white rounded-3xl border-4 border-slate-100 p-6 sm:p-8 shadow-sm space-y-8 text-left" id="about-module">
      
      {/* Editorial Title */}
      <div className="text-center space-y-2">
        <span className="text-5xl">🧭</span>
        <h2 className="text-2xl sm:text-3xl font-black text-slate-850 font-sans mt-2">
          À propos d'Atlas du monde
        </h2>
        <p className="text-sm font-bold text-sky-500 max-w-lg mx-auto leading-relaxed">
          Un fabuleux passeport d'exploration géographique pour les enfants curieux de 6 à 12 ans !
        </p>
      </div>

      {/* Quick rules bento list */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="p-5 rounded-2xl bg-amber-50/50 border-2 border-amber-100 space-y-2.5">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🗺️</span>
            <h3 className="font-extrabold text-sm text-slate-800">1. Découvre les Continents</h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed font-medium">
            Navigue sur notre carte interactive ou clique directement sur les 7 continents pour afficher tous les pays phares rattachés.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-emerald-50/50 border-2 border-emerald-100 space-y-2.5">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📚</span>
            <h3 className="font-extrabold text-sm text-slate-800">2. Encyclopédie pour Enfants</h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed font-medium">
            Lis les anecdotes amusantes « Le Savais-tu ? » pour chaque pays, apprends d'où vient leur drapeau et admire des illustrations faites main.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-violet-50/50 border-2 border-violet-100 space-y-2.5">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🏆</span>
            <h3 className="font-extrabold text-sm text-slate-800">3. Teste tes connaissances</h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed font-medium">
            Lance des quiz interactifs pour tester ta mémoire géographique et débloque des badges d'honneur comme le trophée Maître Géographe Suprême !
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-sky-50/50 border-2 border-sky-100 space-y-2.5">
          <div className="flex items-center gap-2">
            <span className="text-2xl">💡</span>
            <h3 className="font-extrabold text-sm text-slate-800">4. Recherche Instantanée</h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed font-medium">
            Saisis n'importe quel pays ou capitale dans notre barre de recherche magique située en haut pour atterrir directement sur sa fiche.
          </p>
        </div>
      </div>

      {/* Editorial Mission note */}
      <div className="p-6 rounded-2xl bg-slate-50 border-2 border-slate-100 space-y-3 relative overflow-hidden">
        <div className="absolute -bottom-8 -right-8 text-8xl opacity-5 pointer-events-none select-none">❤️</div>
        <h3 className="font-black text-sm text-slate-800 flex items-center gap-1.5">
          <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
          Notre Mission Ludique et Éducative
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed font-medium max-w-2xl">
          Atlas du monde souhaite éveiller la curiosité des jeunes enfants face à l'immense richesse culturelle et naturelle de notre planète Terre. En simplifiant les données (population de « copains », faits insolites captivants plutôt que des tableaux infinis), nous transformons l'apprentissage en une aventure palpitante.
        </p>
      </div>

      {/* Guide de Sauvegarde sur Mobile */}
      <div className="p-6 rounded-3xl bg-sky-50 border-4 border-sky-100 space-y-5" id="mobile-download-guide">
        <div className="flex items-center gap-3">
          <span className="text-3xl animate-pulse">📱</span>
          <div>
            <h3 className="font-black text-md text-slate-800 font-sans">
              Guide : Comment télécharger ton site depuis ton mobile ?
            </h3>
            <p className="text-[11px] text-sky-600 font-bold">
              Le bouton "Export to ZIP" est parfois masqué sur mobile, voici comment le retrouver !
            </p>
          </div>
        </div>

        <div className="space-y-4 text-xs text-slate-750">
          <div className="flex gap-3 items-start bg-white p-4 rounded-2xl border-2 border-sky-100/50">
            <span className="text-2xl bg-sky-50 px-2 py-1 rounded-xl font-bold">🔄</span>
            <div>
              <h4 className="font-black text-slate-800 text-sm mb-1">Méthode 1 : Bascule en mode Paysage (Recommandé)</h4>
              <p className="text-slate-600 leading-relaxed font-medium">
                Tourne simplement ton téléphone de côté pour l'utiliser à l'horizontal. L'écran de Google AI Studio va s'agrandir et révéler automatiquement la barre d'outils complète contenant le bouton de téléchargement <strong>"Export as ZIP"</strong> dans les options.
              </p>
            </div>
          </div>

          <div className="flex gap-3 items-start bg-white p-4 rounded-2xl border-2 border-sky-100/50">
            <span className="text-2xl bg-sky-50 px-2 py-1 rounded-xl font-bold">🖥️</span>
            <div>
              <h4 className="font-black text-slate-800 text-sm mb-1">Méthode 2 : Active la "Version pour Ordinateur"</h4>
              <p className="text-slate-600 leading-relaxed font-medium">
                Dans ton navigateur mobile (Chrome ou Safari) : clique sur l'icône de menu (trois petits points ou <span className="font-mono">aA</span>) et sélectionne <strong>"Version pour ordinateur"</strong>. L'interface d'AI Studio se rechargera en version complète avec tous les menus d'exportation accessibles !
              </p>
            </div>
          </div>

          <div className="flex gap-3 items-start bg-white p-4 rounded-2xl border-2 border-sky-100/50">
            <span className="text-2xl bg-sky-50 px-2 py-1 rounded-xl font-bold">⚙️</span>
            <div>
              <h4 className="font-black text-slate-800 text-sm mb-1">Méthode 3 : Cherche le Menu de Configuration</h4>
              <p className="text-slate-600 leading-relaxed font-medium">
                Regarde tout en bas à gauche de l'écran ou au niveau des barres d'outils latérales de l'éditeur Google AI Studio. Clique sur l'icône de la petite roue crantée (Settings ⚙️) ou sur la barre de menu supérieure pour déplier les options d'export et de téléchargement de code.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-sky-100/40 p-3.5 rounded-2xl text-[11px] font-semibold text-sky-800 border border-sky-200 text-center">
          💡 <strong>Astuce :</strong> Une fois le fichier ZIP téléchargé sur ton mobile, tu pourras l'extraire ou l'envoyer par e-mail / iCloud / Google Drive pour l'ouvrir sur n'importe quel ordinateur !
        </div>
      </div>

      {/* Footer sign off */}
      <div className="text-center pt-4 border-t border-slate-100 text-[10px] font-bold text-slate-400 font-mono">
        FAIT AVEC AMOUR ET PASSION POUR LES FUTURS EXPLORATEURS 🧭 🌿
      </div>

    </div>
  );
}
