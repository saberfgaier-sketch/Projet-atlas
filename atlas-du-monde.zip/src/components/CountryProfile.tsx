import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, BookOpen, MapPin, Landmark as LandmarkIcon, Check, Users, HelpCircle, Trophy } from 'lucide-react';
import { Country, Continent } from '../types';
import LandscapePreview from './LandscapePreview';

interface CountryProfileProps {
  country: Country;
  continent: Continent;
  onBackToContinent: (continent: Continent) => void;
  onBackToWorld: () => void;
}

export default function CountryProfile({
  country,
  continent,
  onBackToContinent,
  onBackToWorld
}: CountryProfileProps) {

  const containerVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4 }
    }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="space-y-8 text-left"
      id={`country-profile-viewer-${country.id}`}
    >
      {/* Back & Breadcrumbs Panel */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white/60 p-3 rounded-2xl border border-slate-100">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-500 font-mono">
          <button onClick={onBackToWorld} className="hover:text-sky-600 transition-colors">ACCEUIL PLANÈTE</button>
          <span>/</span>
          <button onClick={() => onBackToContinent(continent)} className="hover:text-sky-600 uppercase transition-colors">{continent.name}</button>
          <span>/</span>
          <span className="text-slate-800 font-black">{country.name.toUpperCase()}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onBackToContinent(continent)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-black text-xs rounded-full transition-colors font-sans"
            id="back-to-continent-btn"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Vers {continent.name}</span>
          </button>
        </div>
      </div>

      {/* Main Flag & Header Banner matching Vibrant Palette style */}
      <div className="bg-indigo-500 rounded-[2.5rem] p-6 sm:p-10 relative overflow-hidden flex flex-col sm:flex-row items-center gap-6 shadow-xl text-white">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_50%_120%,#ffffff_0%,transparent_50%)] pointer-events-none"></div>
        <span className="relative z-10 text-6xl sm:text-7xl p-4 bg-white/10 rounded-2xl shadow-md border-2 border-white/20 animate-wiggle shrink-0 text-center">{country.flag}</span>
        <div className="relative z-10 text-center sm:text-left flex-grow">
          <span className="text-[10px] font-black tracking-widest text-indigo-200 uppercase font-mono block">
            Fiche d'identité nationale
          </span>
          <h2 className="text-3xl sm:text-5xl font-black font-sans tracking-tight mt-1 leading-tight">
            {country.name}
          </h2>
          <p className="text-sm font-bold text-indigo-150 mt-1.5 flex items-center justify-center sm:justify-start gap-1">
            <span>🌍 Situé dans le magnifique continent :</span>
            <span className="text-amber-400 font-extrabold capitalize underline">{continent.name}</span>
          </p>
        </div>
        {/* Large floating indicator */}
        <div className="hidden lg:flex absolute right-12 top-1/2 -translate-y-1/2 w-32 h-32 bg-white/10 rounded-full border-4 border-white/20 items-center justify-center text-6xl rotate-12 select-none animate-wiggle">
          🗼
        </div>
      </div>

      {/* Grid Layout of Country Information */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Fun Identity Passport & Landscape Preview (Span 5) */}
        <div className="lg:col-span-12 xl:col-span-5 space-y-8">
          
          {/* Fun Identity Card styled to copy Vibrant Palette */}
          <div className="bg-white rounded-3xl p-6 border-b-8 border-sky-400 shadow-sm relative overflow-hidden">
            {/* Stamp watermark */}
            <div className="absolute -bottom-6 -right-6 w-28 h-28 border-4 border-sky-200/40 rounded-full flex items-center justify-center rotate-12 pointer-events-none font-mono font-black text-xs text-sky-300/[0.15] select-none">
              EXPLORATEUR ATLAS
            </div>

            <h3 className="text-sky-500 font-black text-lg mb-4 flex items-center gap-2 border-b border-sky-100 pb-2">
              📇 Carte d'identité
            </h3>

            <ul className="space-y-4">
              <li className="flex flex-col">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest font-mono">Capitale</span>
                <span className="text-lg font-bold text-slate-800">{country.capital}</span>
              </li>
              <li className="flex flex-col border-t border-slate-50 pt-2.5">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest font-mono">Nombre de copains</span>
                <span className="text-lg font-bold text-slate-800">{country.population}</span>
              </li>
              <li className="flex flex-col border-t border-slate-50 pt-2.5">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest font-mono">Langue parlée</span>
                <span className="text-lg font-bold text-slate-800">{country.language}</span>
              </li>
              <li className="flex flex-col border-t border-slate-50 pt-2.5">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest font-mono">Pièces et billets de poche</span>
                <span className="text-lg font-bold text-slate-800">{country.currency}</span>
              </li>
            </ul>
          </div>

          {/* Interactive Landscape Preview */}
          <LandscapePreview 
            countryId={country.id} 
            name={country.name} 
            illustrationDescription={country.illustrationDescription} 
          />
        </div>

        {/* Right Side: Fun Facts & Monuments / Cities (Span 7) */}
        <div className="lg:col-span-12 xl:col-span-7 space-y-8">
          
          {/* Section "Le Savais-tu ?" in gorgeous bright amber card */}
          <div className="bg-amber-50 rounded-3xl p-6 border-2 border-amber-200 relative overflow-hidden shadow-xs">
            <div className="absolute -right-4 -top-4 text-7xl opacity-10 select-none">💡</div>
            
            <h3 className="text-amber-600 font-black text-lg mb-4 flex items-center gap-2 border-b border-amber-200/50 pb-2">
              <span className="p-1 px-2.5 bg-amber-200 text-amber-800 rounded-xl">💡</span>
              Le Savais-tu ?
            </h3>

            <div className="space-y-3 font-semibold text-amber-900">
              {country.funFacts.map((fact, index) => (
                <div key={index} className="flex gap-3 items-start bg-white/70 p-3.5 rounded-2xl shadow-3xs border border-amber-100">
                  <div className="p-1.5 bg-amber-200 text-amber-850 rounded-full shrink-0 text-xs font-black select-none">
                    {index + 1}
                  </div>
                  <p className="text-xs sm:text-sm leading-relaxed font-semibold italic">
                    "{fact}"
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Key Cities & Famous Monuments tab/lists */}
          <div className="bg-white rounded-3xl border-4 border-slate-100 p-6 shadow-xs space-y-6">
            
            {/* Landmarks / Famous Monuments inside responsive grid */}
            <div>
              <h3 className="text-lg font-black text-slate-800 mb-4 flex items-center gap-2 border-b border-slate-100 pb-2">
                <span className="p-1 bg-rose-100 text-rose-800 rounded-xl">🏛️</span>
                Les grands monuments à visiter absolument
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {country.landmarks.map((landmark, idx) => {
                  const frames = ['bg-rose-100', 'bg-emerald-100', 'bg-sky-100', 'bg-amber-100'];
                  const frameColor = frames[idx % frames.length];
                  const emojis = ['🏛️', '🏔️', '🏰', '🗿', '🎡'];
                  const emoji = emojis[idx % emojis.length];
                  return (
                    <div 
                      key={landmark.id} 
                      className="bg-white rounded-3xl p-4 shadow-3xs border border-slate-100 flex flex-col items-center text-center gap-3 hover:scale-103 transition-all cursor-default"
                    >
                      <div className={`w-full h-24 ${frameColor} rounded-2xl flex items-center justify-center text-4xl select-none animate-wiggle`}>
                        {emoji}
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-extrabold text-xs sm:text-sm text-slate-800 leading-tight">{landmark.name}</h4>
                        <p className="text-[10px] sm:text-xs text-slate-500 leading-normal font-semibold">
                          {landmark.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* List major cities mapping */}
            <div>
              <h3 className="text-lg font-black text-slate-800 mb-3 flex items-center gap-2">
                <span className="p-1 bg-emerald-100 text-emerald-800 rounded-xl">🏙️</span>
                Les plus grandes villes du pays
              </h3>
              
              <div className="flex flex-wrap gap-2.5">
                {country.cities.map((city, index) => (
                  <span 
                    key={index}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 text-emerald-800 font-extrabold text-xs rounded-2xl border border-emerald-100 shadow-3xs"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    {city} {city === country.capital ? '👑' : ''}
                  </span>
                ))}
              </div>
              <span className="text-[11px] text-slate-400 font-bold block mt-2 font-mono">
                👑 Ville couronnée = Capitale nationale
              </span>
            </div>

          </div>

        </div>
      </div>

      {/* Direct Quick Fun Mini-game Hook for kids */}
      <div className="bg-gradient-to-r from-violet-100 via-indigo-100 to-sky-100/60 p-6 rounded-3xl border-4 border-violet-200 text-center space-y-4">
        <h3 className="text-xl font-black text-violet-900 flex items-center justify-center gap-2">
          <span>🧠</span>
          <span>Prêt à tester ta mémoire magique ?</span>
        </h3>
        <p className="text-xs sm:text-sm font-semibold text-violet-800/80 max-w-xl mx-auto">
          Arriveras-tu à deviner à quel continent appartient <strong className="text-violet-900">{country.name}</strong> ou quelle est sa capitale officielle dans notre jeu de quiz ?
        </p>
        <div className="flex justify-center gap-3">
          <button 
            onClick={onBackToWorld}
            className="px-4 py-2 bg-white hover:bg-slate-50 border-2 border-violet-300 text-violet-800 font-bold text-xs rounded-full shadow-xs transition-colors"
          >
            🗺️ Carte du Monde
          </button>
          <button 
            onClick={() => {
              // trigger global tab change or custom action
              onBackToWorld(); // first reset to map view
              // we can let App.tsx handle tabs directly inside container
              const quizBtn = document.getElementById('nav-quiz-btn');
              if (quizBtn) quizBtn.click();
            }}
            className="px-5 py-2 bg-violet-600 hover:bg-violet-700 text-white font-extrabold text-xs rounded-full shadow-md transition-colors"
          >
            🎯 Lancer le Quiz Géant
          </button>
        </div>
      </div>
    </motion.div>
  );
}
