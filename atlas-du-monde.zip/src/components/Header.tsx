import React, { useState, useRef, useEffect } from 'react';
import { Search, Compass, Trophy, Info, Globe, Sparkles } from 'lucide-react';
import { CONTINENTS_DATA } from '../data';
import { Country } from '../types';

interface HeaderProps {
  activeTab: 'explore' | 'quiz' | 'about';
  setActiveTab: (tab: 'explore' | 'quiz' | 'about') => void;
  onSelectCountry: (country: Country) => void;
}

export default function Header({ activeTab, setActiveTab, onSelectCountry }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<Country[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const suggestionRef = useRef<HTMLDivElement>(null);

  // Close suggestions when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (suggestionRef.current && !suggestionRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle search filtering
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);

    if (value.trim().length < 2) {
      setSuggestions([]);
      return;
    }

    const matched: Country[] = [];
    const lowerQuery = value.toLowerCase();

    CONTINENTS_DATA.forEach((continent) => {
      continent.countries.forEach((country) => {
        // Search by country name, capital, or cities
        if (
          country.name.toLowerCase().includes(lowerQuery) ||
          country.capital.toLowerCase().includes(lowerQuery) ||
          country.cities.some((c) => c.toLowerCase().includes(lowerQuery))
        ) {
          matched.push(country);
        }
      });
    });

    setSuggestions(matched);
    setShowSuggestions(true);
  };

  const selectSuggestion = (country: Country) => {
    onSelectCountry(country);
    setSearchQuery('');
    setSuggestions([]);
    setShowSuggestions(false);
    setActiveTab('explore');
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b-4 border-sky-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo Brand matching Vibrant Palette */}
          <div 
            className="flex items-center gap-3 cursor-pointer group shrink-0"
            onClick={() => setActiveTab('explore')}
            id="logo-brand"
          >
            <div className="w-12 h-12 bg-sky-500 rounded-2xl flex items-center justify-center text-white text-3xl shadow-lg group-hover:scale-105 transition-transform duration-300">
              🌍
            </div>
            <div>
              <h1 className="text-3xl font-black text-sky-600 tracking-tight font-sans">
                Atlas <span className="text-amber-500 font-black">du monde</span>
              </h1>
              <span className="text-xs font-bold text-sky-450 uppercase tracking-wider block -mt-1 font-mono">
                L'aventure géographique pour enfants 🧭
              </span>
            </div>
          </div>
 
          {/* Search bar with Vibrant Palette styling */}
          <div className="relative flex-1 max-w-md w-full" ref={suggestionRef}>
            <div className="relative flex items-center">
              <input
                type="text"
                placeholder="Chercher un pays, une ville..."
                value={searchQuery}
                onChange={handleSearchChange}
                onFocus={() => searchQuery.trim().length >= 2 && setShowSuggestions(true)}
                className="w-full py-2.5 pl-12 pr-4 bg-sky-50 text-slate-800 placeholder-slate-400 rounded-full border-4 border-sky-100 focus:outline-none focus:border-sky-300 text-base font-bold transition-all focus:ring-4 focus:ring-sky-100/50"
                id="search-input"
              />
              <span className="absolute left-4 text-2xl select-none pointer-events-none">🔍</span>
            </div>

            {/* Suggestions dropdown */}
            {showSuggestions && suggestions.length > 0 && (
              <div className="absolute left-0 right-0 mt-2 bg-white rounded-3xl border-4 border-sky-200 shadow-xl max-h-72 overflow-y-auto z-50 divide-y-2 divide-sky-100 font-sans">
                <div className="px-4 py-2 bg-sky-50 text-xs font-black text-sky-800 uppercase tracking-wider">
                  Résultats trouvés
                </div>
                {suggestions.map((country) => (
                  <button
                    key={country.id}
                    onClick={() => selectSuggestion(country)}
                    className="w-full text-left px-4 py-3 hover:bg-sky-50 transition-colors flex items-center justify-between"
                  >
                    <div>
                      <span className="text-xl mr-2">{country.flag}</span>
                      <span className="font-bold text-slate-800">{country.name}</span>
                      <span className="text-xs text-sky-500 block">Capitale : {country.capital}</span>
                    </div>
                    <span className="text-xs bg-sky-100 text-sky-700 font-bold px-2.5 py-1 rounded-full capitalize">
                      {country.continentId}
                    </span>
                  </button>
                ))}
              </div>
            )}
            {showSuggestions && searchQuery.length >= 2 && suggestions.length === 0 && (
              <div className="absolute left-0 right-0 mt-2 bg-white rounded-3xl border-4 border-rose-150 shadow-xl p-4 text-center text-sm font-bold text-rose-700 z-50">
                Aucun pays ou capitale ne correspond à "{searchQuery}" 😊.
              </div>
            )}
          </div>
 
          {/* Active / Inactive Buttons aligned with Vibrant Palette */}
          <nav className="flex items-center gap-3">
            <button
              onClick={() => {
                setActiveTab('explore');
                setSearchQuery('');
              }}
              className={`px-5 py-2.5 rounded-full font-bold text-base transition-all duration-350 cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'explore'
                  ? 'bg-amber-400 text-white shadow-md scale-105'
                  : 'bg-sky-100 text-sky-600 hover:bg-sky-200 hover:scale-105'
              }`}
              id="nav-explore-btn"
            >
              <Compass className="w-4 h-4 shrink-0" />
              <span>Exploration</span>
            </button>
            <button
              onClick={() => setActiveTab('quiz')}
              className={`px-5 py-2.5 rounded-full font-bold text-base transition-all duration-350 cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'quiz'
                  ? 'bg-amber-400 text-white shadow-md scale-105'
                  : 'bg-sky-100 text-sky-600 hover:bg-sky-200 hover:scale-105'
              }`}
              id="nav-quiz-btn"
            >
              <Trophy className="w-4 h-4 shrink-0" />
              <span>Quiz</span>
            </button>
            <button
              onClick={() => setActiveTab('about')}
              className={`px-5 py-2.5 rounded-full font-bold text-base transition-all duration-350 cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'about'
                  ? 'bg-rose-500 text-white shadow-md scale-105'
                  : 'bg-rose-100 text-rose-500 hover:bg-rose-200 hover:scale-105'
              }`}
              id="nav-about-btn"
            >
              <Info className="w-4 h-4 shrink-0" />
              <span>À Propos</span>
            </button>
          </nav>

        </div>
      </div>
    </header>
  );
}
