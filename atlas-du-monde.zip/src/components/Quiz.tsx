import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Award, Star, Flame, RotateCcw, CheckCircle2, XCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { QUIZ_QUESTIONS } from '../data';
import { QuizQuestion } from '../types';

interface QuizProps {
  onAwardStars?: (amount: number) => void;
}

export default function Quiz({ onAwardStars }: QuizProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  
  const currentQuestion = QUIZ_QUESTIONS[currentQuestionIndex];

  const handleAnswerSelect = (option: string) => {
    if (isAnswered) return;
    setSelectedAnswer(option);
    setIsAnswered(true);

    if (option === currentQuestion.correctAnswer) {
      setScore(prev => prev + 1);
      setStreak(prev => prev + 1);
      onAwardStars?.(100); // Earn 100 stars!
    } else {
      setStreak(0);
    }
  };

  const handleNextQuestion = () => {
    setSelectedAnswer(null);
    setIsAnswered(false);

    if (currentQuestionIndex + 1 < QUIZ_QUESTIONS.length) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setIsFinished(true);
    }
  };

  const handleRestartQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setScore(0);
    setStreak(0);
    setIsAnswered(false);
    setIsFinished(false);
  };

  // Fun badges derived from score
  const getBadgeName = (finalScore: number) => {
    if (finalScore <= 3) return { label: "🧭 Jeune Aventurier", desc: "Continue d'explorer, de fabuleuses contrées t'attendent !", color: "bg-orange-50 text-orange-850 border-orange-200" };
    if (finalScore <= 7) return { label: "🗺️ Navigateur de l'Atlas", desc: "Impressionnant ! Tu connais très bien la Terre et ses secrets !", color: "bg-sky-50 text-sky-850 border-sky-200" };
    return { label: "👑 Maître Géographe Suprême", desc: "Incroyable ! Tu es un véritable génie de la géographie planétaire !", color: "bg-amber-100 text-amber-950 border-amber-300 animate-bounce" };
  };

  const badge = getBadgeName(score);

  return (
    <div className="max-w-2xl mx-auto space-y-8" id="quiz-module">
      
      {/* 1. Header Score & Streak Board */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border-4 border-amber-100 shadow-xs flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2 font-sans">
          <span className="text-xl">🌟</span>
          <span className="text-sm font-extrabold text-slate-700">
            Score : <span className="text-xl font-black text-amber-500">{score}</span> / {QUIZ_QUESTIONS.length}
          </span>
        </div>

        {/* Level indicator bar */}
        <div className="flex items-center gap-2">
          <Star className="w-5 h-5 text-amber-400 fill-amber-300 animate-spin-slow" />
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest font-mono">
            {currentQuestionIndex + 1} / {QUIZ_QUESTIONS.length} Questions
          </span>
        </div>

        {/* Streak indicator */}
        <div className="flex items-center gap-1.5 px-3 py-1 bg-rose-50 rounded-full border border-rose-100">
          <Flame className={`w-5 h-5 ${streak > 0 ? 'text-red-500 fill-red-400 animate-bounce' : 'text-slate-300'}`} />
          <span className="text-xs font-extrabold text-rose-800">
            Série : {streak}
          </span>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!isFinished ? (
          <motion.div
            key={currentQuestion.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-3xl border-4 border-slate-100 p-6 sm:p-8 shadow-sm space-y-6"
            id={`quiz-question-card-${currentQuestion.id}`}
          >
            {/* Question visual category tag */}
            <div className="flex items-center gap-2">
              <span className="px-3.5 py-1.5 bg-violet-100 text-violet-800 text-xs font-black uppercase tracking-wider rounded-xl font-mono">
                {currentQuestion.type === 'capital' && '👑 Devine la capitale'}
                {currentQuestion.type === 'flag' && '🏁 Drapeaux Mystères'}
                {currentQuestion.type === 'continent' && '🗺️ À quel continent appartient ?'}
                {currentQuestion.type === 'landmark' && '🏛️ Monuments du bout du monde'}
              </span>
            </div>

            {/* Question text */}
            <h3 className="text-lg sm:text-xl font-black text-slate-800 font-sans leading-snug">
              {currentQuestion.questionText}
            </h3>

            {/* Answer Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {currentQuestion.options.map((option, index) => {
                const isSelected = selectedAnswer === option;
                const isCorrect = option === currentQuestion.correctAnswer;
                
                let buttonStyle = 'border-slate-100 bg-slate-50 text-slate-800 hover:bg-slate-100 border-3 hover:border-slate-300';
                
                if (isAnswered) {
                  if (isCorrect) {
                    buttonStyle = 'border-emerald-400 bg-emerald-50 text-emerald-950 font-black ring-4 ring-emerald-100 border-3';
                  } else if (isSelected) {
                    buttonStyle = 'border-rose-400 bg-rose-50 text-rose-950 ring-4 ring-rose-100 border-3 line-through';
                  } else {
                    buttonStyle = 'border-slate-100 bg-slate-50 text-slate-400 opacity-60 border-3';
                  }
                }

                return (
                  <motion.button
                    whileTap={{ scale: isAnswered ? 1 : 0.98 }}
                    disabled={isAnswered}
                    key={index}
                    onClick={() => handleAnswerSelect(option)}
                    className={`w-full text-left px-5 py-3.5 rounded-2xl text-sm font-bold transition-all duration-200 flex items-center justify-between gap-2 ${buttonStyle}`}
                    id={`quiz-option-${index}`}
                  >
                    <span>{option}</span>
                    {isAnswered && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />}
                    {isAnswered && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-rose-500 shrink-0" />}
                  </motion.button>
                );
              })}
            </div>

            {/* Feedback explanations */}
            {isAnswered && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-4 rounded-2xl border-2 flex items-start gap-3 text-left ${
                  selectedAnswer === currentQuestion.correctAnswer
                    ? 'bg-emerald-50 border-emerald-100 text-emerald-900'
                    : 'bg-rose-50 border-rose-100 text-rose-900'
                }`}
                id="quiz-feedback-box"
              >
                <div className="text-2xl pt-0.5">
                  {selectedAnswer === currentQuestion.correctAnswer ? '🎉' : '💡'}
                </div>
                <div>
                  <h4 className="font-extrabold text-sm mb-1">
                    {selectedAnswer === currentQuestion.correctAnswer ? 'Bonne réponse !' : 'Oups ! La bonne réponse était : ' + currentQuestion.correctAnswer}
                  </h4>
                  <p className="text-xs sm:text-sm font-medium leading-relaxed opacity-95">
                    {currentQuestion.funExplanation}
                  </p>
                </div>
              </motion.div>
            )}

            {/* Navigation buttons */}
            {isAnswered && (
              <div className="flex justify-end pt-2">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={handleNextQuestion}
                  className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-extrabold rounded-2xl shadow-md transition-colors flex items-center gap-2 cursor-pointer"
                  id="quiz-next-btn"
                >
                  <span>
                    {currentQuestionIndex + 1 < QUIZ_QUESTIONS.length ? 'Question Suivante' : 'Terminer le Quiz'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </div>
            )}

          </motion.div>
        ) : (
          <motion.div
            key="finished"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl border-4 border-slate-100 p-8 shadow-sm text-center space-y-6"
            id="quiz-finished-card"
          >
            <div className="text-6xl animate-bounce">🏆</div>
            
            <div>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-800">Votre score d'explorateur :</h2>
              <div className="text-4xl font-black text-amber-500 mt-2 font-mono">{score} / {QUIZ_QUESTIONS.length}</div>
            </div>

            {/* Progress bar visual background */}
            <div className="bg-slate-100 h-4 w-full rounded-full overflow-hidden max-w-sm mx-auto border-2 border-slate-200">
              <div 
                className="bg-amber-400 h-full rounded-full transition-all duration-1000"
                style={{ width: `${(score / QUIZ_QUESTIONS.length) * 100}%` }}
              />
            </div>

            {/* Custom badge earned */}
            <div className={`p-6 rounded-3xl border-3 max-w-md mx-auto relative overflow-hidden ${badge.color}`}>
              <ShieldCheck className="w-12 h-12 mx-auto stroke-amber-500/30 absolute -top-2 right-4 rotate-12" />
              <div className="text-xs font-black uppercase tracking-widest font-mono opacity-80 mb-1">Badge Débloqué</div>
              <h4 className="text-lg font-black">{badge.label}</h4>
              <p className="text-xs font-bold leading-relaxed mt-2 p-1 bg-white/40 rounded-xl">{badge.desc}</p>
            </div>

            {/* Restart quiz */}
            <div className="flex justify-center pt-4">
              <button
                onClick={handleRestartQuiz}
                className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-sm rounded-2xl shadow-md transition-colors flex items-center gap-2.5 cursor-pointer"
                id="quiz-restart-btn"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Recommencer la Partie</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
