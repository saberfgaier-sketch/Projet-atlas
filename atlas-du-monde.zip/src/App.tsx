import { useState } from 'react';
import { CONTINENTS_DATA } from './data';
import { Continent, Country } from './types';
import Header from './components/Header';
import Explorer from './components/Explorer';
import CountryProfile from './components/CountryProfile';
import Quiz from './components/Quiz';
import About from './components/About';
import { Compass, Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'explore' | 'quiz' | 'about'>('explore');
  const [focusedContinent, setFocusedContinent] = useState<Continent | null>(null);
  const [focusedCountry, setFocusedCountry] = useState<Country | null>(null);

  // Handle a direct country selection from Header search or list cards
  const handleSelectCountry = (country: Country) => {
    // Find parent continent
    const parentContinent = CONTINENTS_DATA.find((c) => c.id === country.continentId);
    if (parentContinent) {
      setFocusedContinent(parentContinent);
    }
    setFocusedCountry(country);
  };

  const handleBackToContinent = (continent: Continent) => {
    setFocusedContinent(continent);
    setFocusedCountry(null);
  };

  const handleBackToWorld = () => {
    setFocusedContinent(null);
    setFocusedCountry(null);
  };

  // We can track stars
  const [stars, setStars] = useState<number>(() => {
    const saved = localStorage.getItem('explorer_stars_total');
    return saved ? parseInt(saved, 10) : 1240;
  });

  const handleAwardStars = (amount: number) => {
    setStars((prev) => {
      const next = prev + amount;
      localStorage.setItem('explorer_stars_total', next.toString());
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-sky-50 flex flex-col font-sans selection:bg-sky-100 selection:text-sky-900 text-slate-800" id="main-app-container">
      {/* 1. Playful Navigation Header */}
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onSelectCountry={handleSelectCountry} 
      />

      {/* 2. Main content area with Sidebar + Main Content Grid */}
      <div className="flex-grow max-w-7xl w-full mx-auto px-4 py-6 sm:px-6 lg:px-8 flex flex-col md:flex-row gap-6">
        
        {/* Sidebar: Continent Selector */}
        <aside className="w-full md:w-64 shrink-0 flex flex-col gap-3">
          <div className="bg-white/80 backdrop-blur-md p-4 rounded-3xl border-4 border-sky-100/80 shadow-3xs space-y-4">
            <div>
              <h2 className="text-sm font-black text-sky-500 uppercase tracking-widest px-1">Les 7 Continents</h2>
              <p className="text-[10px] text-slate-400 font-bold px-1">Choisis ta destination !</p>
            </div>
            
            <div className="flex flex-row md:flex-col overflow-x-auto md:overflow-x-visible pb-2 md:pb-0 gap-2 shrink-0 scrollbar-none">
              {/* World / All Reset button */}
              <div 
                onClick={handleBackToWorld}
                className={`p-3 rounded-2xl flex items-center gap-2.5 shadow-3xs cursor-pointer transition-all duration-255 text-xs shrink-0 md:w-full ${
                  !focusedContinent 
                    ? 'bg-amber-400 text-white font-black shadow-xs' 
                    : 'bg-sky-50 text-sky-700 font-bold hover:bg-sky-100/80 border border-sky-100'
                }`}
                id="sidebar-all-continents"
              >
                <span className="text-lg">🌍</span>
                <span>Toute la Terre</span>
              </div>

              {CONTINENTS_DATA.map((continent) => {
                const isSelected = focusedContinent?.id === continent.id;
                return (
                  <div 
                    key={continent.id}
                    onClick={() => {
                      setFocusedContinent(continent);
                      setFocusedCountry(null);
                      setActiveTab('explore');
                    }}
                    className={`p-3 rounded-2xl flex items-center gap-2.5 shadow-3xs cursor-pointer transition-all duration-255 text-xs shrink-0 md:w-full ${
                      isSelected 
                        ? 'bg-white border-b-4 border-sky-500 border-2 border-sky-200 font-black shadow-xs' 
                        : 'bg-white/50 hover:bg-white text-slate-600 hover:text-slate-800 font-bold border-2 border-transparent hover:border-sky-100'
                    }`}
                    id={`sidebar-card-${continent.id}`}
                  >
                    <span className="text-xl shrink-0">{continent.illuSymbol}</span>
                    <span className={isSelected ? 'text-sky-600' : ''}>{continent.name}</span>
                  </div>
                );
              })}
            </div>

            {/* Score box matching Vibrant Palette */}
            <div className="pt-2 border-t border-sky-100">
              <div className="p-4 bg-amber-100 rounded-3xl border-2 border-dashed border-amber-300">
                <p className="text-[10px] font-black text-amber-600 tracking-wider mb-2">TON SCORE</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-amber-500 leading-none">{stars.toLocaleString()}</span>
                  <span className="text-xl animate-bounce">⭐</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Major Content display */}
        <main className="flex-grow w-full md:max-w-[calc(100%-17rem)]">
          {/* Tab 1: Geographical Explorer */}
          {activeTab === 'explore' && (
            <div id="tab-explore-content">
              {focusedCountry ? (
                // If exploring a specific country, show its dashboard profile
                <CountryProfile
                  country={focusedCountry}
                  continent={focusedContinent || CONTINENTS_DATA[0]}
                  onBackToContinent={handleBackToContinent}
                  onBackToWorld={handleBackToWorld}
                />
              ) : (
                // Else, show world maps or continent filter cards
                <Explorer
                  focusedContinent={focusedContinent}
                  setFocusedContinent={setFocusedContinent}
                  focusedCountry={focusedCountry}
                  setFocusedCountry={setFocusedCountry}
                  onSelectCountry={handleSelectCountry}
                />
              )}
            </div>
          )}

          {/* Tab 2: Gamified Quiz Tab */}
          {activeTab === 'quiz' && (
            <div id="tab-quiz-content" className="space-y-4">
              <div className="text-center space-y-2 mb-8 bg-white/70 p-6 rounded-3xl border-2 border-amber-100">
                <span className="text-5xl animate-bounce inline-block">🧠</span>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-800 tracking-tight">
                  Le Quiz des Explorateurs de l'Atlas !
                </h2>
                <p className="text-sm font-bold text-amber-600 max-w-md mx-auto leading-relaxed">
                  Réponds correctement aux questions pour gagner des étoiles étincelantes et décrocher tes diplômes géographiques honorifiques !
                </p>
              </div>
              <Quiz onAwardStars={handleAwardStars} />
            </div>
          )}

          {/* Tab 3: About Screen */}
          {activeTab === 'about' && (
            <div id="tab-about-content">
              <About />
            </div>
          )}
        </main>

      </div>

      {/* 3. Footer Section with design bar */}
      <footer className="bg-slate-800 text-slate-400 py-6 mt-12 border-t-8 border-sky-400 text-center relative overflow-hidden">
        {/* Playful background blobs */}
        <div className="absolute top-0 left-0 w-24 h-24 bg-sky-500/5 rounded-full blur-xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex items-center justify-between text-xs flex-col sm:flex-row gap-4">
            <div className="flex gap-4">
              <span>Session: Petit Explorateur</span>
              <span>•</span>
              <span>Temps d'aventure: Actif</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Serveur connecté - Prêt pour l'aventure 🗺️</span>
            </div>
          </div>
          
          <div className="pt-4 border-t border-slate-700 text-[10px] font-bold text-slate-500 font-mono tracking-widest uppercase flex flex-col sm:flex-row justify-between items-center gap-2">
            <span>© 2026 Atlas du Monde • Explore, Apprends & Protège ! 🌱</span>
            <span>CRAFTED WITH INTENSE PASSION 🧭</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
