import { Country } from './types';

// Large high-density compressed string containing all the world's extra countries.
// Format on each line:
// continentId | id | name | capital | flag | population | language | currency | funFact | landmarkName | landmarkDesc
const RAW_COUNTRIES_TEXT = `europe|allemagne|L'Allemagne|Berlin|🇩🇪|84 millions|Allemand|Euro (€)|Il y a plus de 300 types de pains différents dans leurs boulangeries !|La Porte de Brandebourg|Un splendide arc de triomphe symbole de paix et d'histoire.
europe|royaume_uni|Le Royaume-Uni|Londres|🇬🇧|67 millions|Anglais|Livre sterling (£)|Le château de Windsor est le plus ancien château habité au monde !|Big Ben|La fameuse horloge monumentale du Parlement.
europe|portugal|Le Portugal|Lisbonne|🇵🇹|10 millions|Portugais|Euro (€)|C'est le plus grand producteur de liège de la planète, l'écorce de chênes !|La Tour de Belém|Une magnifique tour fortifiée au bord du fleuve Tage.
europe|belgique|La Belgique|Bruxelles|🇧🇪|11 millions|Français, Néerlandais|Euro (€)|Les célèbres Schtroumpfs et Tintin ont été imaginés par des dessinateurs belges !|L'Atomium|Une sculpture géante représentant un cristal de fer agrandi.
europe|pays_bas|Les Pays-Bas|Amsterdam|🇳🇱|17 millions|Néerlandais|Euro (€)|C'est le pays des millions de tulipes multicolores et des moulins à vent !|Les Canaux d'Amsterdam|De magnifiques voies d'eau bordées de maisons étroites.
europe|suisse|La Suisse|Berne|🇨🇭|9 millions|Allemand, Français, Italien|Franc suisse (CHF)|Ses vaches portent de grosses cloches dorées pour ne pas se perdre dans l'Alpe !|Le Cervin|Une montagne légendaire en forme de pyramide courbe.
europe|autriche|L'Autriche|Vienne|🇦🇹|9 millions|Allemand|Euro (€)|La capitale Vienne invite à de somptueux bals de valses impériales majestueux !|Le Palais de Schönbrunn|Une immense résidence d'été impériale entourée de labyrinthes.
europe|grece|La Grèce|Athènes|🇬🇷|10 millions|Grec|Euro (€)|C'est la patrie historique des premiers Jeux Olympiques d'été et de la mythologie !|L'Acropole d'Athènes|Une colline sacrée couronnée de temples antiques majestueux.
europe|suede|La Suède|Stockholm|🇸🇪|10 millions|Suédois|Couronne suédoise (SEK)|Certains hôtels de Laponie y sont construits entièrement en vraie glace !|Le Musée Vasa|Un magnifique navire de guerre préservé depuis l'année 1628.
europe|norvege|La Norvège|Oslo|🇳🇴|5 millions|Norvégien|Couronne norvégienne (NOK)|C'est le royaume féerique des fjords d'eau turquoise et des aurores boréales !|Le Fjord de Geiranger|Une vallée inondée spectaculaire entourée de hautes falaises sauvages.
europe|danemark|Le Danemark|Copenhague|🇩🇰|6 millions|Danois|Couronne danoise (DKK)|C'est le pays magique où ont été inventées les briques de jeu LEGO !|La Petite Sirène|Une jolie statue de bronze sagement assise au bord de l'eau.
europe|finlande|La Finlande|Helsinki|🇫🇮|5 millions|Finnois|Euro (€)|C'est la maison officielle et enneigée du vrai Père Noël en Laponie !|Le Village du Père Noël|Un parc d'attractions hivernal magique traversé par le cercle polaire.
europe|pologne|La Pologne|Varsovie|🇵🇱|38 millions|Polonais|Zloty (PLN)|Elle possède d'incroyables mines de sel décorées de statues souterraines sculptées !|Le Château de Wawel|Une magnifique forteresse de rois située au bord de la Vistule.
europe|irlande|L'Irlande|Dublin|🇮🇪|5 millions|Irlandais, Anglais|Euro (€)|L'île verte abrite des légendes de Leprechauns qui cachent des marmites d'or !|Les Falaises de Moher|Des falaises géantes plongeant de 200 mètres dans l'océan.
europe|ukraine|L'Ukraine|Kiev|🇺🇦|38 millions|Ukrainien|Hryvnia|C'est l'un des plus grands producteurs de fleurs de tournesols fleuris !|La Cathédrale Sainte-Sophie|Idoine d'histoire avec ses superbes onze clochers dorés brillants.
europe|roumanie|La Roumanie|Bucarest|🇷🇴|19 millions|Roumain|Leu|Elle abrite le mystérieux château de Bran, cher à la légende de Dracula !|Le Château de Peles|Un superbe palais de dessin animé de style Renaissance allemande.
europe|rep_tcheque|La République Tchèque|Prague|🇨🇿|10 millions|Tchèque|Couronne tchèque (CZK)|La ville de Prague possède un pont de pierre gothique orné de 30 statues !|Le Pont Charles|Le plus célèbre monument de Prague unissant la vieille ville historique.
europe|hongrie|La Hongrie|Budapest|🇭🇺|9 millions|Hongrois|Forint|Le célèbre casse-tête du Cube de Rubik y a été inventé par Ernő Rubik !|Le Parlement de Budapest|Un palais magnifique qui brille de mille feux dans le fleuve Danube.
europe|islande|L'Islande|Reykjavik|🇮🇸|380 000|Islandais|Couronne islandaise|C'est un pays de glace et de feu rempli de geysers et de volcans actifs !|Le Lagon Bleu|Une grande piscine d'eau chaude thermale au milieu d'un champ de lave.
europe|croatie|La Croatie|Zagreb|🇭🇷|4 millions|Croate|Euro (€)|La fameuse race de chiens Dalmatiens tire son nom d'une de ses côtes !|Le Parc de Plitvice|Seize magnifiques lacs turquoise reliés par des cascades féeriques.
europe|bulgarie|La Bulgarie|Sofia|🇧🇬|6 millions|Bulgare|Lev bulgare|C'est l'un des plus grands producteurs d'huile parfumée de roses au monde !|Le Monastère de Rila|Un magnifique sanctuaire de montagne décoré d'arcades peintes.
europe|slovaquie|La Slovaquie|Bratislava|🇸🇰|5 millions|Slovaque|Euro (€)|C'est le pays qui possède le plus grand nombre de châteaux par habitant !|Le Château de Spiš|Une gigantesque ruine de château fort trônant sur sa colline verte.
europe|lituanie|La Lituanie|Vilnius|🇱🇹|2.8 millions|Lituanien|Euro (€)|Elle abrite une impressionnante colline couverte de sorcières faites de bois !|Le Château de Trakai|Un fort rouge gothique magnifiquement posé sur une île de lac.
europe|lettonie|La Lettonie|Riga|🇱🇻|1.8 million|Letton|Euro (€)|Le premier sapin de Noël public de la terre y a été dressé en 1510 !|La Maison des Têtes Noires|Un monument historique au style baroque merveilleux.
europe|estonie|L'Estonie|Tallinn|🇪🇪|1.3 million|Estonien|Euro (€)|Plus de la moitié de l'Estonie est couverte de forêts pleines d'animaux sauvages !|La Vieille Ville de Tallinn|De formidables remparts médiévaux et des toits pointus rouges.
europe|slovenie|La Slovénie|Ljubljana|🇸🇮|2 millions|Slovène|Euro (€)|La capitale Ljubljana possède de superbes ponts gardés par des dragons d'acier !|Le Lac de Bled|Un lac émeraude comprenant une charmante église perchée sur un îlot.
europe|luxembourg|Le Luxembourg|Luxembourg|🇱🇺|660 000|Luxembourgeois, Français|Euro (€)|Le train, le tramway et les bus sont gratuits pour absolument tout le monde !|Les Casemates du Bock|Un labyrinthe de fortifications taillé sous les collines de la ville.
europe|malte|Malte|La Valette|🇲🇹|530 000|Maltais, Anglais|Euro (€)|Les temples préhistoriques de l'île de Gozo sont plus anciens que les pyramides !|La Co-cathédrale Saint-Jean|Une église dorée recouverte de marbres fins et d'art baroque.
europe|chypre|Chypre|Nicosie|🇨🇾|1.2 million|Grec, Turc|Euro (€)|La déesse de la beauté Aphrodite y est née selon le conte de l'écume marine !|Le Rocher d'Aphrodite|Un rocher légendaire qui baigne sous les vagues calmes de Chypre.
europe|andorre|L'Andorre|Andorre-la-Vieille|🇦🇩|80 000|Catalan|Euro (€)|C'est un tout petit pays de montagne logé dans le haut des Pyrénées !|L'Église de Sant Joan|Une charmante église romane en pierres s'élevant dans la vallée.
europe|monaco|Monaco|Monaco|🇲🇨|39 000|Français|Euro (€)|C'est le pays du Grand Prix urbain de Formule 1 et des palais fleuris !|Le Palais Princier|La résidence de la famille Grimaldi qui domine les flots bleus.
europe|liechtenstein|Le Liechtenstein|Vaduz|🇱🇮|39 000|Allemand|Franc suisse (CHF)|C'est un mini-pays alpin d'Europe réputé pour ses châteaux perchés !|Le Château de Vaduz|Le château habité par les princes qui offre un panorama sur le Rhin.
europe|saint_marin|Saint-Marin|Saint-Marin|🇸🇲|34 000|Italien|Euro (€)|C'est l'une des plus anciennes et petites républiques du monde entier !|Les Trois Tours|Trois superbes forts reliés par des chemins au sommet du pic Titano.
europe|albanie|L'Albanie|Tirana|🇦🇱|2.8 millions|Albanais|Lek|Secouer la tête de gauche à droite y signifie 'Oui' par politesse nationale !|Le Château de Gjirokastër|Une grande citadelle de pierre blanche dominant la vallée verte.
europe|bosnie|La Bosnie-Herzégovine|Sarajevo|🇧🇦|3.2 millions|Bosnien, Serbe|Mark convertible|La forêt de Perućica y est l'une des dernières forêts vierges sauvages !|Le Pont de Mostar|Un beau pont de pierre en forme de croissant au-dessus de la rivière Neretva.
europe|macedoine|La Macédoine du Nord|Skopje|🇲🇰|2 millions|Macédonien|Denar|La capitale possède un grand nombre de statues de bronze de héros de contes !|Le Pont de Pierre|Un pont d'époque ottoman qui unit deux quartiers de Skopje.
europe|montenegro|Le Monténégro|Podgorica|🇲🇪|620 000|Monténégrin|Euro (€)|Son nom signifie 'Montagne Noire' à cause de ses épaisses forêts sombres !|Les Bouches de Kotor|Un magnifique fjord de montagne bordant des églises médiévales.
europe|serbie|La Serbie|Belgrade|🇷🇸|6.6 millions|Serbe|Dinar serbe|Elle est l'un des plus grands vergers de framboises mûres de la terre !|La Forteresse de Belgrade|Un immense ouvrage fortifié abritant des fosses et bastions.
europe|moldavie|La Moldavie|Chisinau|🇲🇩|2.6 millions|Roumain|Leu|Elle possède l'une des plus grandes caves de vins souterraines du globe !|La Cave de Milestii Mici|Une ville souterraine de bouteilles s'étendant sur 200 km.
europe|bielorussie|La Biélorussie|Minsk|🇧🇾|9.2 millions|Biélorusse|Rouble biélorusse|Elle abrite les derniers dinosaures ou plutôt bisons géants d'Europe !|Le Château de Mir|Un édifice historique aux touches de briques rouges gothiques.
europe|kosovo|Le Kosovo|Pristina|🇽🇰|1.8 million|Albanais, Serbe|Euro (€)|C'est l'un des plus jeunes pays d'Europe, indépendant depuis 2008 !|Le Monastère de Gracanica|Un monument spirituel byzantin fait de briques anciennes.
europe|vatican|Le Vatican|Cité du Vatican|🇻🇦|800|Italien, Latin|Euro (€)|C'est le plus petit pays souverain de la Terre, protégé par la Garde Suisse !|La Chapelle Sixtine|Le chef-d'œuvre pictural de Michel-Ange sous la voûte céleste.
europe|gibraltar|Gibraltar|Gibraltar|🇬🇮|34 000|Anglais|Livre de Gibraltar|C'est le seul endroit sauvage d'Europe habité par des singes en liberté !|Le Rocher de Gibraltar|Une falaise géante dominant l'entrée de la mer Méditerranée.
europe|iles_feroe|Les Îles Féroé|Tórshavn|🇫🇴|53 000|Féroïen, Danois|Couronne danoise|Les moutons y sont plus nombreux que les fiers marins de l'archipel !|La Cascade de Mulafossur|Une cascade géante plongeant directement du haut d'une verte falaise.
asie|indonesie|L'Indonésie|Jakarta|🇮🇩|273 millions|Indonésien|Roupie indonésienne (IDR)|C'est le plus grand royaume d'îles du monde avec plus de 17 000 îles !|Le Temple de Borobudur|Le plus grand temple bouddhiste au monde, construit au IXe siècle.
asie|pakistan|Le Pakistan|Islamabad|🇵🇰|220 millions|Ourdou|Roupie pakistanaise|Le pays possède l'un des plus grands réseaux d'irrigation de la planète !|La Mosquée Faisal|Une splendide mosquée blanche en forme de tente de désert.
asie|bangladesh|Le Bangladesh|Dacca|🇧🇩|170 millions|Bengali|Taka|C'est la maison sacrée des somptueux tigres sauvages du Bengale !|Le Fort de Lalbagh|Un complexe fortifié de grès rouge d'époque moghole.
asie|russie|La Russie|Moscou|🇷🇺|144 millions|Russe|Rouble russe|Elle est tellement large qu'elle s'étend sur onze fuseaux horaires !|La Place Rouge|La célèbre esplanade historique abritant la cathédrale de Basile.
asie|turquie|La Turquie|Ankara|🇹🇷|85 millions|Turc|Lire turque|Istanbul est la seule grande ville posée à cheval sur deux continents !|La Basilique Sainte-Sophie|Une cathédrale devenue mosquée célèbre pour son immense coupole dorée.
asie|vietnam|Le Vietnam|Hanoï|🇻🇳|98 millions|Vietnamien|Dong (VND)|Le Vietnam est l'un des royaumes du riz et de superbes rizières en terrasses !|La Baie de Ha Long|Une multitude de pitons rocheux jaillissant d'eaux d'émeraude.
asie|philippines|Les Philippines|Manille|🇵🇭|113 millions|Filipino|Peso philippin|Il y a plus de 7600 magnifiques îles tropicales à explorer en pirogue !|Les Collines de Chocolat|De curieuses petites collines qui brunissent en saison chaude.
asie|iran|L'Iran|Téhéran|🇮🇷|88 millions|Persan|Rial iranien|C'est la patrie historique des célèbres chats Persans à la longue fourrure !|Le Palais du Golestan|Un somptueux complexe royal de miroirs et de verrières ornées.
asie|thailande|La Thaïlande|Bangkok|🇹🇭|71 millions|Thaï|Baht (THB)|Les éléphants y sont vénérés comme des animaux sacrés porteurs de chance !|Le Temple de l'Aube (Wat Arun)|Un superbe temple décoré de mosquées et faïences multicolores.
asie|birmanie|La Birmanie|Naypyidaw|🇲🇲|54 millions|Birman|Kyat|Elle possède des milliers de pagodes dorées éparpillées en forêt !|La Pagode Shwedagon|Un immense clocher d'or jaillissant au milieu de Yangon.
asie|coree_sud|La Corée du Sud|Séoul|🇰🇷|51 millions|Coréen|Won|C'est la patrie du sport Taekwondo, du chant K-pop et de superbes robots !|Le Palais Gyeongbokgung|Un magnifique château royal d'époque Joseon bordé de saules ronds.
asie|coree_nord|La Corée du Nord|Pyongyang|🇰🇵|26 millions|Coréen|Won nord-coréen|Son grand stade du Premier-Mai est l'un des plus grands au monde !|La Tour du Juche|Une haute colonne d'acier s'élançant le long du fleuve de la capitale.
asie|irak|L'Irak|Bagdad|🇮🇶|43 millions|Arabe, Kurde|Dinar irakien|Il abritait les ruines de Babylone et l'une des premières écritures de l'humanité !|Le Site de Babylone|La Porte historique d'Ishtar d'un bleu azur flamboyant.
asie|afghanistan|L'Afghanistan|Kaboul|🇦🇫|40 millions|Dari|Afghani|Les batailles aériennes de cerfs-volants y sont un art national très ancien !|La Vallée de Bamiyan|De grandes falaises creusées de niches à statues royales.
asie|arabie_saoudite|L'Arabie Saoudite|Riyad|🇸🇦|35 millions|Arabe|Riyal saoudien|Elle abrite le plus grand désert de sable continu nommé le Quart Vide !|Le Site d'Hégra|De fantastiques tombeaux gravés sous la roche sableuse.
asie|ouzbekistan|L'Ouzbékistan|Tachkent|🇺🇿|35 millions|Ouzbek|Sum ouzbek|C'est un carrefour magique de l'ancienne Route de la Soie aux faïences bleues !|La Place du Régistan|Une immense place encadrée de trois universités anciennes de grès.
asie|yemen|Le Yémen|Sanaa|🇾🇪|30 millions|Arabe|Rial yéménite|La cité fortifiée de Shibam est appelée le Manhattan du désert pour sa terre !|La Vieille Ville de Sanaa|Des gratte-ciels en terre et briques ornés de jolies arabesques blanches.
asie|nepal|Le Népal|Katmandou|🇳🇵|30 millions|Népalais|Roupie népalaise|Il abrite le majestueux Mont Everest, Toit de l'Univers terrestre !|Le Temple de Swayambhunath|Le célèbre temple bouddhiste aux yeus peints protecteurs.
asie|sri_lanka|Le Sri Lanka|Sri Jayawardenepura Kotte|🇱🇰|22 millions|Cingalais, Tamoul|Roupie de Sri Lanka|Une île merveilleuse réputée pour ses plantations parfumées de thé !|Le Rocher de Sigiriya|Une forteresse de pierre rouge taillée en forme de lion couché.
asie|kazakhstan|Le Kazakhstan|Astana|🇰🇿|19 millions|Kazakh, Russe|Tenge|C'est le plus grand pays du monde n'ayant aucune frontière côtière !|La Tour Bayterek|Un monument couronné d'un grand œuf doré protégeant un secret d'oiseau.
asie|syrie|La Syrie|Damas|🇸🇾|21 millions|Arabe|Livre syrienne|La ville de Damas est l'une des plus anciennes continuellement habitées !|La Grande Mosquée de Damas|Un temple à colonnades romaine orné de belles mosaïques d'or.
asie|cambodge|Le Cambodge|Phnom Penh|🇰🇭|16 millions|Khmer|Riel|Son temple géant d'Angkor Wat est gravé de visages de rois souriants !|Le Temple d'Angkor Wat|Le fleuron de l'ancienne cité de l'Empire khmer au milieu des eaux.
asie|jordanie|La Jordanie|Amman|🇯🇴|11 millions|Arabe|Dinar jordanien|Contient l'incroyable cité antique de Pétra sculptée dans la grès rouge !|Le Trésor de Pétra|La façade de temple sculptée à main d'homme dans le canyon rose.
asie|azerbaidjan|L'Azerbaïdjan|Bakou|🇦🇿|10 millions|Azéri|Manat|Appelée la Terre de Feu car des gaz naturels s'échappent et brûlent de la roche !|La Tour de la Vierge|Une tour médiévale entourée d'énigmes historiques à Bakou.
asie|eau|Les Émirats Arabes Unis|Abou Dabi|🇦🇪|10 millions|Arabe|Dirham des EAU|Le gratte-ciel Burj Khalifa est si haut qu'il touche les nuages à Dubaï !|La Tour Burj Khalifa|La pointe d'acier de 828 mètres qui domine la baie bleue.
asie|tadjikistan|Le Tadjikistan|Douchanbé|🇹🇯|10 millions|Tadjik|Somoni|Près du trois quarts de son territoire est recouvert de montagnes rocheuses !|Le Parc National du Tadjikistan|Ses glaciers et plaines s'élevant aux confins de la chaîne du Pamir.
asie|israel|Israël|Jérusalem|🇮🇱|9.5 millions|Hébreu, Arabe|Shekel|On flotte tout seul dans sa Mer Morte tellement l'eau y est salée !|Le Mur occidental|Les antiques pierres gravées chargées d'histoire.
asie|laos|Le Laos|Vientiane|🇱🇦|7.5 millions|Laotien|Kip|Surnommé le pays du million d'éléphants paisibles marchant en forêt !|Le Pha That Luang|Un grand reliquaire bouddhiste entièrement recouvert de feuilles d'or.
asie|liban|Le Liban|Beyrouth|🇱🇧|5.3 millions|Arabe|Livre libanaise|L'arbre de cèdre est gravé au cœur de son drapeau d'éternité !|Le Temple de Bacchus|L'un des plus grands et mieux conservés des temples romains d'Asie.
asie|kirghizistan|Le Kirghizistan|Bichkek|🇰🇬|6.6 millions|Kirghize, Russe|Som|Les familles nomades aiment dormir dans d'accueillantes tentes rondes yourtes !|Le Lac Son-Köl|Un lac de montagnes herbeuses bleuté sous les vols d'aigles.
asie|turkmenistan|Le Turkménistan|Achgabat|🇹🇲|6.3 millions|Turkmène|Manat|La fameuse Porte de l'Enfer y brûle au cœur du désert noir depuis 50 ans !|Le Cratère de Darvaza|Un gouffre géant enflammé scintillant au milieu des dunes de nuit.
asie|singapour|Singapour|Singapour|🇸🇬|5.6 millions|Anglais|Dollar de Singapour|Une vraie cité-jardin futuriste où la verdure escalade les gratte-ciels !|Les Supertrees|De gigantesques structures décorées de centaines de plantes grimpantes.
asie|oman|Le Oman|Mascate|🇴🇲|4.5 millions|Arabe|Rial omanais|Célèbre pour ses voiliers d'écorce de Sinbad le Marin naviguant les mers !|Le Fort de Bahla|Une majestueuse muraille de terre entourée de palmiers et d'oasis.
asie|palestine|La Palestine|Ramallah|🇵🇸|5.2 millions|Arabe|Shekel|Les oliviers sacrés y sont soignés d'âges en âges de père en fils !|La Basilique de la Nativité|L'une des plus anciennes et calmes basiliques romaines.
asie|koweit|Le Koweït|Koweït|🇰🇼|4.3 millions|Arabe|Dinar de Koweït|Il dresse d'incroyables tours d'eau aux jolis cercles de mosaïques bleues !|Les Tours de Koweït|Trois flèches d'époque d'acier ornées de sphères colorées.
asie|georgie|La Géorgie|Tbilissi|🇬🇪|3.7 millions|Géorgien|Lari|Elle est reconnue comme le berceau d'origine de la culture de la vigne !|Le Monastère de Gelati|Une œuvre d'art royale médiévale aux coupoles et livres anciens.
asie|mongolie|La Mongolie|Oulan-Bator|🇲🇳|3.3 millions|Mongol|Tugrik|C'est le pays du ciel bleu permanent où courent les chevaux de steppe !|La Statue équestre de Gengis Khan|Une statue en acier de 40 mètres brillant dans les steppes d'herbe.
asie|armenie|L'Arménie|Erevan|🇦🇲|3 millions|Arménien|Dram|Le mont Ararat sacré veille fièrement devant l'horizon de sa capitale !|Le Temple de Garni|Un superbe temple gréco-romain orné de grandes colonnes claires.
asie|qatar|Le Qatar|Doha|🇶🇦|2.7 millions|Arabe|Riyal qatarien|Le bel oiseau faucon y est un compagnon de chasse royal très aimé !|Le Musée d'Art Islamique|Une prouesse d'architecture de dalles de calcaire blanches sur la mer.
asie|bahrein|Le Bahreïn|Manama|🇧🇭|1.5 million|Arabe|Dinar de Bahreïn|Un arbre y pousse seul sans eau visible depuis 400 ans dans le désert !|L'Arbre de Vie|Un arbre de jasmin miraculeux trônant au milieu des sables.
asie|timor|Le Timor Oriental|Dili|🇹🇱|1.3 million|Portugais|Dollar US ($)|Le lézard crocodile y est vénéré comme un habitant créateur de l'île !|La Statue du Christ de Dili|Une grande statue dominant de magnifiques lagons et coraux.
asie|bhoutan|Le Bhoutan|Thimphou|🇧🇹|780 000|Dzongkha|Ngultrum|Il mesure la joie de vivre de ses habitants via le Bonheur National Brut !|Le Nid du Tigre|Un monastère de bois et de chaux suspendu au flanc d'une falaise verte.
asie|maldives|Les Maldives|Malé|🇲🇻|520 000|Maldivien|Rufiyaa|Le pays regroupe près de 1200 bancs d'atolls de récifs de coraux et sables !|Les Atolls Coralliens|Des cercles d'eau magiques fréquentés par les raies mantas.
asie|brunei|Le Brunei|Bandar Seri Begawan|🇧🇳|450 000|Malais|Dollar de Brunei|Le palais royal du Sultan abrite plus de 1700 salons plaqués d'or !|La Mosquée d'Omar|Une pièce maîtresse d'art religieux dotée de dômes d'or pur.
afrique|nigeria|Le Nigéria|Abuja|🇳🇬|213 millions|Anglais|Naira|Sa production de films de Nollywood surpasse en quantité celle de Hollywood !|Le Rocher de Zuma|Un monolithe rocheux géant qui sert de repère de route majeur.
afrique|ethiopie|L'Éthiopie|Addis-Abeba|🇪🇹|120 millions|Amharique|Birr|C'est ici qu'on a découvert le plant de caféier grâce à des chèvres sauteuses !|Les Églises de Lalibela|Onze églises médiévales taillées d'une seule pièce dans la roche.
afrique|rdc|La R.D. du Congo|Kinshasa|🇨🇩|95 millions|Français|Franc congolais|La forêt vierge du pays abrite de grands gorilles des montagnes !|Le Parc de Kahuzi-Biega|Le sanctuaire de forêt dense abritant les gorilles des plaines de l'Est.
afrique|tanzanie|La Tanzanie|Dodoma|🇹🇿|63 millions|Swahili, Anglais|Shilling tanzanien|Elle abrite le mont Kilimandjaro, majestueux sommet d'Afrique !|Le Cratère du Ngorongoro|Une caldeira géante abritant des milliers d'animaux sauvages.
afrique|kenya|Le Kenya|Nairobi|🇰🇪|53 millions|Swahili|Shilling kenyan|Les girafes et lions y vivent en liberté au milieu de douces plaines !|La Réserve de Masai Mara|Une plaine herbeuse et vallonnée traversée par les zèbres de la savane.
afrique|ouganda|L'Ouganda|Kampala|🇺🇬|45 millions|Anglais|Shilling ougandais|Surnommé la Perle de l'Afrique pour sa luxuriante nature verte !|Le Parc de Bwindi|La forêt impénétrable protégeant les gorilles des brumes rudes.
afrique|algerie|L'Algérie|Alger|🇩🇿|44 millions|Arabe, Berbère|Dinar algérien|C'est le plus grand pays du continent noir, dominé par le désert du Sahara !|Le Monument de la Victoire|Trois feuilles de palmier de béton symbole de renaissance à Alger.
afrique|soudan|Le Soudan|Khartoum|🇸🇩|45 millions|Arabe|Livre soudanaise|Il possède plus de pyramides de grès de pharaons que l'Egypte elle-même !|Les Pyramides de Méroé|Une série de tombes aux allures profilées d'ocres au désert.
afrique|angola|Le Angola|Luanda|🇦🇴|34 millions|Portugais|Kwanza|Ses forêts de baobabs abritent d'incroyables espèces de singes et de fleurs !|Les Chutes de Kalandula|De géantes chutes d'eaux d'Amazonie africaine de 105 mètres de haut.
afrique|mozambique|Le Mozambique|Maputo|🇲🇿|32 millions|Portugais|Metical|Ses eaux de récifs côtiers abritent de gentils dugongs herbivores nageurs !|Le Fort de San Sebastian|Une forteresse de pierre d'époque portugaise qui fait face à la mer.
afrique|ghana|Le Ghana|Accra|🇬🇭|32 millions|Anglais|Cedi|Le Ghana produit de merveilleuses récoltes de fèves pour faire le chocolat !|Le Fort de Cape Coast|Un grand fort côtoyant le ressac marin, chargé de récits de mer.
afrique|cote_divoire|La Côte d'Ivoire|Yamoussoukro|🇨🇮|27 millions|Français|Franc CFA|Elle possède la Basilique Notre-Dame de la Paix, la plus vaste de la terre !|La Basilique de Yamoussoukro|Une réplique géante de Saint-Pierre dotée de superbes vitraux fins.
afrique|madagascar|Madagascar|Antananarivo|🇲🇬|28 millions|Malgache, Français|Ariary|Le pays est le sanctuaire officiel des lémuriens et des baobabs géants !|L'Allée des Baobabs|Une voie de latérite rouge bordée d'arbres bouteilles millénaires.
afrique|cameroun|Le Cameroun|Yaoundé|🇨🇲|27 millions|Français, Anglais|Franc CFA|Surnommé L'Afrique en miniature car on y croise tous les types de paysages !|Le Parc de Waza|Un parc herbeux habité par de joyeux éléphants et autruches de savane.
afrique|niger|Le Niger|Niamey|🇳🇪|25 millions|Français|Franc CFA|On y a trouvé un squelette de dinosaure de 110 millions d'années dans les sables !|Les Falaises de Tiguidit|Un mur de calcaire doré au pied du grand désert d'arbres du Ténéré.
afrique|mali|Le Mali|Bamako|🇲🇱|21 millions|Français|Franc CFA|La grande cité de Tombouctou abrite des mosquées d'argile uniques au monde !|La Mosquée de Djenné|Le plus grand monument de terre pisé du globe, restauré chaque année.
afrique|burkina|Le Burkina Faso|Ouagadougou|🇧🇫|22 millions|Français|Franc CFA|Son beau nom signifie en français La Patrie des Hommes Intègres !|Les Pics de Sindou|De spectaculaires aiguilles de pierre sculptées par le vent sableux.
afrique|malawi|Le Malawi|Lilongwe|🇲🇼|20 millions|Anglais|Kwacha|Son lac est habité par plus d'espèces de poissons de lac que tout autre !|Le Parc de Lake Malawi|Une mer d'eau douce aux poissons cichlidés étincelants de mille feux.
afrique|zambie|La Zambie|Lusaka|🇿🇲|19 millions|Anglais|Kwacha|Elle partage les formidables fumées et geysers des Chutes Victoria !|Le Parc du Bas-Zambèze|Des rivières habitées par des bancs d'hippopotames ronds.
afrique|senegal|Le Sénégal|Dakar|🇸🇳|17 millions|Français, Wolof|Franc CFA|Il possède un lac d'eau couleur rose bonbon d'algues magiques !|L'Île de Gorée|De charmantes ruelles coloniales aux façades roses couvertes de bougainvilliers.
afrique|tchad|Le Tchad|N'Djaména|🇹🇩|17 millions|Français, Arabe|Franc CFA|Il cache dix-huit lacs bleutés d'oasis au milieu d'impressionnantes dunes !|Les Lacs d'Ounianga|Des étendues turquoise posées au creux du grès rouge du Sahara.
afrique|somalie|La Somalie|Mogadiscio|🇸🇴|17 millions|Somali|Shilling somalien|C'est un grand pays côtier réputé pour son parfum naturel d'encens !|La Mosquée de Fakr ad-Din|Une construction de coraux et marbres bâtie par les sultans.
afrique|zimbabwe|Le Zimbabwe|Harare|🇿🇼|15 millions|Anglais|Dollar US ($)|Il possède une incroyable cité médiévale fortifiée aux murs d'époque !|Les Ruines de Great Zimbabwe|Une cité royale de briques de granit assemblées sans ciment.
afrique|guinee|La Guinée|Conakry|🇬🇳|13 millions|Français|Franc guinéen|Surnommée le château d'eau de la région de l'Afrique de l'Ouest !|Le Fouta-Djalon|Une région de cascades, de canyons d'herbe et de roches de basalte.
afrique|rwanda|Le Rwanda|Kigali|🇷🇼|13 millions|Kinyarwanda|Franc rwandais|Le Rwanda est surnommé le joyeux Pays des Mille Collines vertes !|Le Parc de l'Akagera|Un ensemble de savanes lacustres fréquenté par les rhinocéros.
afrique|benin|Le Bénin|Porto-Novo|🇧🇯|13 millions|Français|Franc CFA|La ville lacustre de Ganvié est construite sur pilotis au beau milieu d'un lac !|La Cité de Ganvié|Un village de 20 000 pêcheurs habitant sur des bambous de mer.
afrique|burundi|Le Burundi|Gitega|🇧🇮|12 millions|Kirundi|Franc burundais|Les musiciens nationaux jouent de lourds tambours géants de bois !|La Source du Nil|Une source mystique que le peuple qualifie d'origine du grand fleuve égyptien.
afrique|tunisie|La Tunisie|Tunis|🇹🇳|12 millions|Arabe|Dinar tunisien|La cité de Matmata abrite des maisons souterraines qui ont servi à Star Wars !|L'Amphithéâtre d'El Jem|Un des colisées romains les mieux préservés de la planète.
afrique|soudan_sud|Le Soudan du Sud|Djouba|🇸🇸|11 millions|Anglais|Livre sud-soudanaise|C'est l'un des pays souverains les plus récents de l'histoire, né en 2011 !|Les Plaines de Sudd|Une immense zone humide de roseaux traversée par les gnous migrateurs.
afrique|togo|Le Togo|Lomé|🇹🇬|8.6 millions|Français|Franc CFA|On y croise d'incroyables châteaux de terre fortifiés érigés à la main !|Les Tamberma Koutammakou|Des maisons aux tours d'argile classées à l'UNESCO.
afrique|sierra|La Sierra Leone|Freetown|🇸🇱|8.6 millions|Anglais|Leone|Sa capitale festive Freetown a été construite pour accueillir de fiers marins !|La Plage de River No. 2|Une splendide plage de sables blancs bordée de collines vertes.
afrique|libye|La Libye|Tripoli|🇱🇾|6.7 millions|Arabe|Dinar libyen|La Libye cache d'incroyables cités romaines préservées de grès chaud !|Le Théâtre de Sabratha|Un immense front de scène de calcaire dressé face aux vagues bleues.
afrique|congo|Le Congo-Brazzaville|Brazzaville|🇨🇬|5.8 millions|Français|Franc CFA|Plus de la moitié du pays est couverte d'une jungle dense aux chimpanzés !|Le Parc d'Odzala-Kokoua|Une réserve de gorilles de plaine marchant dans les rivières de forêt.
afrique|centrafrique|La République Centrafricaine|Bangui|🇨🇫|5.5 millions|Sango|Franc CFA|Elle est le paradis des vols de papillons multicolores de lisière de forêt !|Les Chutes de Lancrenon|Des torrents d'eau descendant de reliefs herbeux des savanes.
afrique|liberia|Le Liberia|Monrovia|🇱🇷|5.2 millions|Anglais|Dollar libérien|C'est la plus ancienne république proclamée d'Afrique depuis 1847 !|Le Parc de Sapo|Une réserve magique d'animaux protégés et d'arbres géants de forêt.
afrique|mauritanie|La Mauritanie|Nouakchott|🇲🇷|4.6 millions|Arabe|Ouguiya|Le plus long train d'acier de la planète y transporte du minerai au désert !|La Cité de Chinguetti|Une bibliothèque de briques et manuscrits anciens cernée par le Sahara.
afrique|erythree|L'Érythrée|Asmara|🇪🇷|3.6 millions|Arabe|Nakfa|La capitale possède de magnifiques édifices de style futuriste italien !|La Cathédrale d'Asmara|Un clocher de briques et tuiles rouges dominant la ville d'altitude.
afrique|gambie|La Gambie|Banjul|🇬🇲|2.6 millions|Anglais|Dalasi|Le pays forme une étroite bande verte bordant les rives fleuries du fleuve !|La Réserve d'Abuko|Une forêt abritant des singes verts et de jolis crocodiles.
afrique|gabon|Le Gabon|Libreville|🇬🇦|2.3 millions|Français|Franc CFA|La forêt vierge recouvre près de quatre-vingt-cinq pour cent de ses terres !|Le Parc de Loango|Une plage côtière où l'on photographie des éléphants de mer.
afrique|namibie|La Namibie|Windhoek|🇳🇦|2.5 millions|Anglais|Dollar namibien|Les dunes de sable rouge de Sossusvlei figurent parmi les plus hautes du monde !|Le Canyon de Fish River|Un immense canyon de pierres dorées s'étirant au milieu du désert.
afrique|lesotho|Le Lesotho|Maseru|🇱🇸|2.2 millions|Sesotho|Loti|Un royaume alpin vert logé en altitude au milieu de l'Afrique du Sud !|L'Inclus de Semonkong|De superbes cascades d'eau se déversant le long de falaises sombres.
afrique|bissau|La Guinée-Bissau|Bissau|🇬🇼|2 millions|Portugais|Franc CFA|Ses îles abritent des hippopotames sauvages qui aiment nager en mer calme !|L'Archipel des Bijagos|Une suite d'îles de collines vertes de mangroves à la vie riche.
afrique|g_eq|La Guinée Équatoriale|Malabo|🇬🇶|1.6 million|Espagnol|Franc CFA|C'est l'unique pays d'Afrique continentale à parler officiellement l'espagnol !|La Cathédrale de Malabo|Une élégante nef gothique blanche se reflétant sur la baie de mer.
afrique|maurice|L'Île Maurice|Port-Louis|🇲🇺|1.3 million|Anglais, Créole|Roupie mauricienne|C'était la maison exclusive du célèbre Dodo, oiseau dodu de forêts !|La Cascade de Chamarel|Cascade jaillissant de roches de laves entourée d'arbres de jungle.
afrique|eswatini|L'Eswatini|Mbabane|🇸🇿|1.2 million|Swati|Lilangeni|Un royaume de montagnes verdoyantes réputé pour ses danses de cérémonies !|Le Parc Royal de Hlane|Plaines à terre rouge habitées par les rhinocéros et oiseaux.
afrique|djibouti|Le Djibouti|Djibouti|🇩🇯|1.1 million|Français, Arabe|Franc de Djibouti|Son grand lac Assal est si salé qu'il brille d'un blanc pur éclatant !|Le Lac Assal|Une cuvette de sel d'un blanc magnifique et d'eau indigo-turquoise.
afrique|comores|Les Comores|Moroni|🇰🇲|820 000|Comorien, Arabe|Franc comorien|On appelle l'archipel des Comores les îles parfumées pour ses ylangs jaunes !|Le Volcan Karthala|Un volcan de cratère géant entouré de forêts habitées d'oiseaux.
afrique|cap_vert|Le Cap-Vert|Praia|🇨🇻|580 000|Portugais|Escudo|Un bel archipel de 10 îles bercé par la poétique musique de colline !|Le Volcan de Fogo|Un grand cône volcanique de basalte foncé dominant les nuages.
afrique|sao_tome|Sao Tomé-et-Principe|Sao Tomé|🇸🇹|225 000|Portugais|Dobra|Une île paradisiaque de forêt appelée l'île chocolat pour ses sèves de cacao !|Le Pico de Sao Tome|Un pic montagneux couvert de végétation humide tropicale.
afrique|seychelles|Les Seychelles|Victoria|🇸🇨|100 000|Créole, Français|Roupie des Seychelles|Célèbre pour ses lagons turquoise de mer et ses tortues géantes !|L'Anse Lazio|Une plage de cocotiers de sables dorés ceinte de magnifiques rochers de granit noirs.
amerique_nord|cuba|Le Cuba|La Havane|🇨🇺|11 millions|Espagnol|Peso cubain|La capitale La Havane abrite de magnifiques voitures vintage colorées de contes !|Le Capitole de La Havane|Un grand palais d'époque entouré de palmiers et de musique salsa.
amerique_nord|haiti|Le Haïti|Port-au-Prince|🇭🇹|11 millions|Français, Créole|Gourde|Le pays a été la première république et port d'insurgés libres de l'océan !|La Citadelle Laferrière|Un énorme fort de briques érigé au sommet de falaises embrumées.
amerique_nord|rep_dom|La République Dominicaine|Saint-Domingue|🇩🇴|11 millions|Espagnol|Peso dominicain|C'est le paradis ensoleillé de la danse Merengue et des récifs de baleines !|La Zone Coloniale de Saint-Domingue|Les plus anciennes rues de pierres d'époque espagnole en Amérique.
amerique_nord|honduras|Le Honduras|Tegucigalpa|🇭🇳|10 millions|Espagnol|Lempira|Contient d'anciennes horloges de clochers magiques toujours en marche !|Les Ruines de Copan|Une magnifique cité maya célèbre pour ses somptueuses sculptures d'aras.
amerique_nord|nicaragua|Le Nicaragua|Managua|🇳🇮|6.8 millions|Espagnol|Cordoba|C'est l'un des seuls endroits où des requins se baignent en eau douce !|Le Volcan Masaya|Un volcan actif fantastique de cratère où l'on voit bouillir la lave.
amerique_nord|salvador|Le Salvador|San Salvador|🇸🇻|6.3 millions|Espagnol|Dollar US ($)|Le pays possède plus de vingt volcans actifs sur de petits territoires de plaines !|Le Site de Joya de Ceren|Un village maya fossilisé sous des cendres de feu, resté intact.
amerique_nord|guatemala|Le Guatemala|Guatemala|🇬🇹|18 millions|Espagnol|Quetzal|La jungle de forêt cache de grandioses temples en pyramide de Tikal !|Les Temples de Tikal|De hautes pyramides mayas qui dominent la canopée de la jungle verte.
amerique_nord|costa_rica|Le Costa Rica|San José|🇨🇷|5.1 millions|Espagnol|Colon|Un quart de ses terres est préservé pour les toucans de forêt humide !|Le Volcan Arenal|Un superbe volcan de forme conique parfaite entouré de sources de soufre.
amerique_nord|panama|Le Panama|Panama|🇵🇦|4.4 millions|Espagnol|Balboa|Son grand canal d'écluses permet de relier deux océans en quelques heures !|Le Canal de Panama|Une merveille d'ingénierie soulevant les bateaux au milieu des montagnes.
amerique_nord|jamaique|La Jamaïque|Kingston|🇯🇲|2.8 millions|Anglais|Dollar jamaïcain|L'île d'origine du célèbre chanteur de reggae Bob Marley et d'Usain Bolt !|Les Chutes de la Dunn|Des cascades d'eau de montagne où l'on se baigne en grimpant.
amerique_nord|bahamas|Les Bahamas|Nassau|🇧🇸|400 000|Anglais|Dollar bahaméen|Une île célèbre de l'archipel abrite d'adorables petits cochons nageurs libres !|La Plage des Cochons|Une plage d'eau turquoise claire où se baignent des porcelets sauvages.
amerique_nord|belize|Le Belize|Belmopan|🇧🇿|400 000|Anglais|Dollar de Belize|Il possède un immense gouffre de mer circulaire visible de l'espace !|Le Grand Trou Bleu|Un gouffre géant bleu marine de 300 mètres entouré de coraux.
amerique_nord|trinite|Trinité-et-Tobago|Port-d'Espagne|🇹🇹|1.5 million|Anglais|Dollar de Trinité|C'est le berceau de l'instrument Steelpan fait de bidons métalliques !|Le Pitch Lake|Un lac de goudron chaud naturel unique de matière géante.
amerique_nord|barbade|La Barbade|Bridgetown|🇧🇧|280 000|Anglais|Dollar de Barbade|Le pays d'origine du poisson volant de mer et de la chanteuse Rihanna !|La Grotte de Harrison|Une magnifique caverne de stalactites de calcaires blancs éclairée.
amerique_nord|sainte_lucie|Sainte-Lucie|Castries|🇱🇨|180 000|Anglais|Dollar des Caraïbes|Possède deux pyramides de lave d'aiguilles célèbres s'élevant de mer !|Les Deux Pitons|Deux impressionnantes montagnes volcaniques pointues de forêt.
amerique_nord|grenade|La Grenade|Saint-Georges|🇬🇩|125 000|Anglais|Dollar des Caraïbes|On l'appelle l'île aux épices d'Amérique pour ses noix de muscade !|Le Parc de Sculptures Sous-marines|Des visages sculptés sous l'eau qui s'allient à la vie des coraux.
amerique_nord|vincent|Saint-Vincent-et-les-Grenadines|Kingstown|🇻🇨|100 000|Anglais|Dollar des Caraïbes|Ses eaux turquoise abritent de fantastiques récifs coralliens et dactyles !|Le Volcan de la Soufrière|Un volcan majestueux actif qui couronne les hauteurs de l'île.
amerique_nord|antigua|Antigua-et-Barbuda|Saint-John's|🇦🇬|100 000|Anglais|Dollar des Caraïbes|On dit de l'île qu'elle possui un nombre de plages égal aux jours d'une année !|Le Chantier Naval de Nelson|Un port historique de bois restauré bordé d'anciennes ancres de pirates.
amerique_nord|saint_christophe|Saint-Christophe-et-Niévès|Basseterre|🇰🇳|47 000|Anglais|Dollar des Caraïbes|C'est le plus petit pays des Amériques par sa superficie côtière !|La Forteresse de Brimstone Hill|Un fort en terrasses de pierres d'époque surnommé Gibraltar des mers.
amerique_nord|dominique|La Dominique|Roseau|🇩🇲|72 000|Anglais|Dollar des Caraïbes|L'île conserve une forêt humide indomptée aux cascades d'eau !|Le Boiling Lake|Un grand lac d'altitude volcanique bouillonnant sous les brumes chaudes.
amerique_nord|groenland|Le Groenland|Nuuk|🇬🇱|56 000|Danois|Couronne danoise|La plus grande île non continentale de la terre, couverte de calotte de glace !|Le Fjord d'Ilulissat|De magnifiques icebergs bleutés descendant lentement des glaciers côtiers.
amerique_sud|argentine|L'Argentine|Buenos Aires|🇦🇷|45 millions|Espagnol|Peso argentin|Le pays du Tango et d'incroyables vachers cowboys nommés Gauchos !|Le Glacier Perito Moreno|Une barrière royale de glace bleue de trente kilomètres de long.
amerique_sud|colombie|La Colombie|Bogota|🇨🇴|52 millions|Espagnol|Peso colombien|Le royaume des oiseaux condors et de délicieuses fèves parfumées de café !|La Cathédrale de Sel|Une majestueuse église construite au cœur d'anciennes mines de sel.
amerique_sud|venezuela|Le Venezuela|Caracas|🇻🇪|28 millions|Espagnol|Bolivar|Il abrite Salto Angel, la plus haute chute d'eau du monde entier !|La Cascade de Salto Angel|Une chute d'eau de 979 mètres jaillissant de montagnes de grès tables.
amerique_sud|chili|Le Chili|Santiago|🇨🇱|19 millions|Espagnol|Peso chilien|Le pays possède l'île de Pâques aux géantes statues de pierre de tuf !|Les Moai de l'Île de Pâques|De colossaux bustes sculptés érodés de pierres de lave noire.
amerique_sud|equateur|L'Équateur|Quito|🇪🇨|18 millions|Espagnol|Dollar US ($)|Les îles Galapagos du pays abritent de gentilles et géantes tortues terrestres !|Les Îles Galapagos|La réserve naturelle d'animaux marins et d'iguanes bleus uniques.
amerique_sud|bolivie|La Bolivie|Sucre|🇧🇴|12 millions|Espagnol, Quechua|Boliviano|Elle abrite le Salar d'Uyuni, splendide désert de sel blanc miroir !|Le Salar d'Uyuni|Un désert de sel de 10 000 kilomètres carrés imitant le ciel d'azur.
amerique_sud|paraguay|Le Paraguay|Asuncion|🇵🇾|6.7 millions|Guarani|Guarani|Le pays de la dentelle brodée à la main appelée toile d'araignée !|Le Barrage d'Itaipu|Une immense centrale hydroélectrique d'un fleuve frontalier.
amerique_sud|uruguay|L'Uruguay|Montevideo|🇺🇾|3.4 millions|Espagnol|Peso uruguayen|Près de la moitié de l'électricité y vient du vent des plaines !|La Villa Casapueblo|Une étonnante bâtisse blanche sculptée s'enfonçant face aux mers bleues.
amerique_sud|guyana|Le Guyana|Georgetown|🇬🇾|800 000|Anglais|Dollar de Guyana|La forêt vierge recouvre près de quatre-vingt-cinq pour cent du pays !|Les Chutes de Kaieteur|Une cascade géante d'eau de 226 mètres de hauteur, d'époque préhistorique.
amerique_sud|suriname|Le Suriname|Paramaribo|🇸🇷|600 000|Néerlandais|Dollar de Suriname|Le plus petit pays d'Amérique du Sud aux jolies maisons de bois peintes !|Le Centre-ville de Paramaribo|Bâtiments coloniaux mélangeant architecture de bois et européenne.
amerique_sud|guyane|La Guyane Française|Cayenne|🇫🇷|300 000|Français|Euro (€)|Elle abrite le grand Centre Spatial Européen de Kourou en plein milieu de jungle !|Le Centre Spatial de Kourou|La plateforme d'envol de la fusée magique Ariane.
oceanie|papouasie|La Papouasie-Nouvelle-Guinée|Port Moresby|🇵🇬|10 millions|Tok Pisin, Anglais|Kina|Le sanctuaire d'origine des merveilleux petits oiseaux de paradis de forêt !|Le Mont Wilhelm|Le plus haut sommet de l'île offrant des panoramas d'herbes et de brumes.
oceanie|fidji|Les Fidji|Suva|🇫🇯|900 000|Anglais|Dollar de Fidji|Un bel archipel de sable blanc réputé pour son accueil chaleureux !|Les Récifs des Fidji|Des lagons turquoise de coraux habités par des milliers de poissons.
oceanie|salomon|Les Îles Salomon|Honiara|🇸🇧|700 000|Anglais|Dollar des Salomon|L'archipel abrite d'impressionnants volcans côtiers au milieu d'eaux calmes !|Le Lagon de Marovo|Le plus grand lagon d'eau salée fermé par des récifs de la planète.
oceanie|vanuatu|Le Vanuatu|Port-Vila|🇻🇺|320 000|Bislama, Français|Vatu|C'est le pays inventeur du saut à l'élastique traditionnel sur liane !|Le Volcan Yasur|Un volcan dont on peut contempler de près les éruptions rouges de feu.
oceanie|samoa|Les Samoa|Apia|🇼🇸|200 000|Samoan|Tala|L'art ancestral du tatouage y est respecté comme un trésor de famille !|La Fosse de To-Sua|Un trou d'eau bleue géant de mer entouré de plantes sauvages.
oceanie|tonga|Les Tonga|Nuku'alofa|🇹🇴|100 000|Anglais|Pa'anga|Le seul royaume d'Océanie à n'avoir jamais été conquis par des puissances !|Les Trous Souffleurs de Houma|De magnifiques geysers de mer jaillissant des récifs de lave.
oceanie|kiribati|Les Kiribati|Tarawa|🇰🇮|120 000|Anglais|Dollar australien|C'est l'un des premiers pays de la terre à saluer le soleil du nouvel an !|L'Atoll de Tarawa|Un lagon de sables blancs bordé de jolies huttes de paille.
oceanie|micronesie|La Micronésie|Palikir|🇫🇲|100 000|Anglais|Dollar US ($)|Elle possède une ancienne cité mystique de basalte construite sur l'eau |Les Ruines de Nan Madol|Des remparts et temples bâtis sur des îlots reliés par des canaux.
oceanie|palaos|Les Palaos|Ngerulmud|🇵🇼|18 000|Anglais|Dollar US ($)|Il possède un lac marin magique peuplé de millions de méduses d'or !|Le Lac aux Méduses|Une étendue d'eau calme où se baigner sans risque à côté de méduses.
oceanie|marshall|Les Îles Marshall|Majuro|🇲🇭|42 000|Anglais|Dollar US ($)|Le pays est une suite d'étroits atolls de sables posés sur le Pacifique !|L'Atoll de Majuro|Une longue barrière de cocotiers de sable blanc entourée d'eau marine.
oceanie|tuvalu|Les Tuvalu|Funafuti|🇹🇻|11 000|Anglais|Dollar australien|L'un des plus petits et bas pays du globe, menacé par l'océan ouvert !|La Lagune de Funafuti|Une réserve de sables sauvages et de palmiers habitée de bernard-l'hermite.
oceanie|nauru|Nauru|Yaren|🇳🇷|10 000|Anglais|Dollar de Nauru|C'est la plus petite république d'île isolée indépendante de la terre !|La Falaise calcaire de Nauru|De drôles de pitons de roches blanches au milieu de fleurs de jasmin.
oceanie|samoa_am|Les Samoa Américaines|Pago Pago|🇦🇸|45 000|Samoan|Dollar US ($)|Elles abritent de superbes chauve-souris rousses friandes de fruits de forêt !|Le Parc National de Pago Pago|Une splendide jungle de collines se jetant dans des criques de mer.
oceanie|polynesie|La Polynésie Française|Papeete|🇵🇫|280 000|Français, Tahitien|Franc CFP|L'île de Tahiti est le paradis des tiare parfumées et des grands lagons !|Le Lagon de Bora Bora|Une eau de nuances turquoise d'atolls de coraux uniques au monde.
oceanie|caledonie|La Nouvelle-Calédonie|Nouméa|🇳🇨|270 000|Français, Kanak|Franc CFP|Elle possède le plus d'espèces d'arbres de pins colonnaires de la planète !|Le Cœur de Voh|Une clairière dessinant un cœur parfait dans les herbes d'une mangrove.`;

// Parse raw data at runtime to generate Country objects
export const ALL_INFLATED_EXTRA_COUNTRIES: Country[] = RAW_COUNTRIES_TEXT.trim()
  .split('\n')
  .map((line) => {
    const parts = line.split('|');
    const [
      continentId,
      id,
      name,
      capital,
      flag,
      populationShort,
      language,
      currency,
      funFact,
      landmarkName,
      landmarkDesc,
    ] = parts;

    return {
      id,
      continentId,
      name,
      capital,
      flag,
      population: `${populationShort} de copains`,
      language,
      currency,
      illustrationDescription: `Un magnifique paysage typique du pays : ${name}, avec sa capitale ${capital} baignée de lumière chaleureuse sous un ciel bleu de contes de fées.`,
      funFacts: [funFact],
      landmarks: [
        {
          id: `${id}_landmark_1`,
          name: landmarkName,
          description: landmarkDesc,
        },
      ],
      cities: [capital],
    };
  });
