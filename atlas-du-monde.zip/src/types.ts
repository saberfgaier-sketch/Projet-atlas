export interface Landmark {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
}

export interface Country {
  id: string;
  name: string;
  capital: string;
  flag: string;
  population: string;
  language: string;
  currency: string;
  funFacts: string[];
  landmarks: Landmark[];
  cities: string[];
  continentId: string;
  illustrationDescription: string;
}

export interface Continent {
  id: string;
  name: string;
  slogan: string;
  description: string;
  color: string; // Tailwind bg-class
  hoverColor: string; // Tailwind hover bg-class
  textColor: string; // Tailwind text-class
  illuSymbol: string; // Emoji representing the continent
  countries: Country[];
}

export interface QuizQuestion {
  id: string;
  type: 'capital' | 'continent' | 'flag' | 'landmark';
  questionText: string;
  options: string[];
  correctAnswer: string;
  funExplanation: string;
}
